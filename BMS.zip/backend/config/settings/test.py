"""Test settings.

Identical to dev, except the database is a throwaway SQLite file so the test
suite can run on a fresh database without a live PostgreSQL/Docker service.
Production and dev still run on PostgreSQL (see `base.py` / `docker-compose.yml`).
"""

from .base import *  # noqa: F401,F403
from .base import BASE_DIR

DEBUG = False

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "test-db.sqlite3",
        "TEST": {"NAME": BASE_DIR / "test-db.sqlite3"},
    }
}

PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]

CELERY_TASK_ALWAYS_EAGER = True
CELERY_TASK_EAGER_PROPAGATES = True

EMAIL_BACKEND = "django.core.mail.backends.locmem.EmailBackend"
