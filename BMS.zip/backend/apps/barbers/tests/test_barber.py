"""Tests for the Barber model."""

import pytest

from django.core.exceptions import ValidationError

from apps.barbers.models import Barber, BarberStatus
from apps.accounts.models import User
from apps.catalog.models import Service
from apps.core.models import Shop

pytestmark = pytest.mark.django_db


def _create_barber(**overrides):
    """Helper to create a Barber with a User, Shop, and default fields."""
    user = User.objects.create_user(
        phone="+15552000001", full_name="Test Barber", pin="1234"
    )
    shop = Shop.objects.create(
        name="Test Shop",
        address_line1="123 Main St",
        city="New York",
        state="NY",
        postal_code="10001",
    )
    defaults = {
        "user": user,
        "shop": shop,
        "display_name": "Test Barber",
        "chair_number": 1,
        "active": True,
    }
    defaults.update(overrides)
    return Barber.objects.create(**defaults)


def test_barber_str():
    barber = _create_barber()
    assert str(barber) == "Test Barber"


def test_barber_user_is_one_to_one():
    barber = _create_barber()
    assert barber.user.full_name == "Test Barber"
    assert User.objects.get(barber_profile=barber).pk == barber.user.pk


def test_barber_role_must_be_barber():
    """Creating a Barber with a non-barber user raises ValidationError."""
    owner = User.objects.create_superuser(
        phone="+15552000002", full_name="Owner", pin="1234"
    )
    shop = Shop.objects.create(
        name="Shop 2",
        address_line1="456 Oak Ave",
        city="New York",
        state="NY",
        postal_code="10002",
    )
    with pytest.raises(ValidationError):
        Barber.objects.create(
            user=owner,
            shop=shop,
            display_name="Owner Barber",
            chair_number=2,
        )


def test_barber_active_default_true():
    barber = _create_barber()
    assert barber.active is True


def test_barber_display_name():
    barber = _create_barber(display_name="Alice Barber")
    assert barber.display_name == "Alice Barber"


def test_barber_chair_number_unique_per_shop():
    """Chair number must be unique across all shops (per model Meta unique constraint)."""
    _create_barber(chair_number=1)
    with pytest.raises(Exception):  # IntegrityError for unique constraint
        _create_barber(chair_number=1)


def test_offered_services_empty_m2m_returns_all_active():
    """When services M2M is empty (not set), offered_services returns all active services."""
    barber = _create_barber()
    s1 = Service.objects.create(
        name="Cut",
        price=25.00,
        duration_minutes=30,
        active=True,
    )
    s2 = Service.objects.create(
        name="Fade",
        price=30.00,
        duration_minutes=45,
        active=True,
    )
    assert barber.offered_services.count() == 2
    assert list(barber.offered_services.values_list("name", flat=True)) == ["Cut", "Fade"]


def test_offered_services_excludes_inactive():
    """offered_services should not include inactive services when M2M is empty."""
    barber = _create_barber()
    Service.objects.create(
        name="Active Service",
        price=10.00,
        duration_minutes=15,
        active=True,
    )
    Service.objects.create(
        name="Inactive Service",
        price=20.00,
        duration_minutes=20,
        active=False,
    )
    names = list(barber.offered_services.values_list("name", flat=True))
    assert names == ["Active Service"]


def test_offered_services_with_selected_services():
    """When services M2M has entries, only those active services are returned."""
    barber = _create_barber()
    s1 = Service.objects.create(name="Service A", price=10.00, duration_minutes=15, active=True)
    s2 = Service.objects.create(name="Service B", price=20.00, duration_minutes=30, active=True)
    Service.objects.create(name="Service C", price=30.00, duration_minutes=45, active=True)
    barber.services.add(s1)
    assert barber.offered_services.count() == 1
    assert barber.offered_services.first().name == "Service A"


def test_offered_services_selected_but_none_active():
    """If barber selected services but all are inactive, returns empty."""
    barber = _create_barber()
    s = Service.objects.create(name="Inactive Only", price=10.00, duration_minutes=15, active=False)
    barber.services.add(s)
    assert barber.offered_services.count() == 0


def test_can_accept_card_payments_not_started():
    barber = _create_barber(
        stripe_onboarding_status=BarberStatus.NOT_STARTED,
    )
    assert barber.can_accept_card_payments is False


def test_can_accept_card_payments_pending():
    barber = _create_barber(
        stripe_onboarding_status=BarberStatus.PENDING,
    )
    assert barber.can_accept_card_payments is False


def test_can_accept_card_payments_complete():
    barber = _create_barber(
        stripe_onboarding_status=BarberStatus.COMPLETE,
    )
    assert barber.can_accept_card_payments is True


def test_stripe_connect_account_id_blank_default():
    barber = _create_barber()
    assert barber.stripe_connect_account_id == ""


def test_rent_defaults():
    barber = _create_barber()
    assert barber.rent_type == "flat_fee"
    assert barber.rent_cycle == "weekly"
    assert barber.rent_amount == 0
    assert barber.rent_due_date is None


def test_barber_str_custom():
    barber = _create_barber(display_name="Alice")
    assert str(barber) == "Alice"


def test_barber_chair_number_unique_across_shop_boundary():
    """
    The unique constraint is on chair_number alone — not per shop.
    So even across different shops, duplicate chair numbers are rejected.
    """
    shop1 = Shop.objects.create(
        name="Shop A",
        address_line1="111 Main",
        city="New York",
        state="NY",
        postal_code="10001",
    )
    shop2 = Shop.objects.create(
        name="Shop B",
        address_line1="222 Main",
        city="New York",
        state="NY",
        postal_code="10002",
    )
    user1 = User.objects.create_user(
        phone="+15552000003", full_name="Barber 1", pin="1234"
    )
    user2 = User.objects.create_user(
        phone="+15552000004", full_name="Barber 2", pin="1234"
    )
    Barber.objects.create(user=user1, shop=shop1, display_name="B1", chair_number=1)
    with pytest.raises(Exception):
        Barber.objects.create(user=user2, shop=shop2, display_name="B2", chair_number=1)
