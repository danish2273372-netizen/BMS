"""Admin registration for the barbers app."""

from django.contrib import admin

from apps.accounts.models import UserRole

from .models import Barber, RentType, BarberStatus


@admin.register(Barber)
class BarberAdmin(admin.ModelAdmin):
    """Admin for barbers."""

    list_display = ("display_name", "user", "shop", "chair_number", "active", "can_accept_card_payments")
    list_filter = ("active", "rent_type", "stripe_onboarding_status", "shop")
    search_fields = ("display_name", "user__phone", "user__full_name")
    readonly_fields = (
        "stripe_connect_account_id",
        "stripe_onboarding_status",
        "created_at",
        "updated_at",
    )
    fieldsets = (
        (None, {"fields": ("user", "shop", "display_name", "photo", "chair_number", "active")}),
        (
            "Rent",
            {
                "fields": ("rent_type", "rent_amount", "rent_cycle", "rent_due_date"),
            },
        ),
        (
            "Services",
            {
                "fields": ("services",),
            },
        ),
        (
            "Stripe",
            {
                "fields": ("stripe_connect_account_id", "stripe_onboarding_status"),
            },
        ),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )

    def has_add_permission(self, request):
        """Only owner/superuser can create barber records."""
        return request.user.is_superuser or request.user.is_owner

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        return False

    def can_accept_card_payments(self, obj):
        return obj.can_accept_card_payments

    can_accept_card_payments.boolean = True
    can_accept_card_payments.short_description = "Accepts card payments"
