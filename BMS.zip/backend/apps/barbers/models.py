"""Barber domain model.

Each barber has a ``Barber`` record linked to their ``accounts.User``,
with Stripe Connect status, chair number (unique per shop), rent details,
and a many-to-many link to the service catalogue.
"""

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.core.validators import MinValueValidator
from django.db import models
from django.utils.translation import gettext_lazy as _

from apps.catalog.models import Service

User = get_user_model()


class RentType(models.TextChoices):
    FLAT_FEE = "flat_fee", _("Flat fee per period")
    PERCENTAGE = "percentage", _("Percentage of gross bookings")


class BarberStatus(models.TextChoices):
    NOT_STARTED = "not_started", _("Not started")
    PENDING = "pending", _("Pending approval")
    COMPLETE = "complete", _("Account complete")


class Barber(models.Model):
    """Profile for a single barber at a shop.

    The ``user`` field is a one-to-one link to a :class:`~accounts.User`
    whose ``role`` must be ``barber``.

    The ``services`` M2M field is intentionally blank-able: when empty,
    :meth:`offered_services` returns every active service in the catalogue.
    """

    user = models.OneToOneField(
        User,
        on_delete=models.CASCADE,
        verbose_name=_("user"),
        related_name="barber_profile",
        limit_choices_to={"role": "barber"},
    )
    shop = models.ForeignKey(
        "core.Shop",
        on_delete=models.CASCADE,
        verbose_name=_("shop"),
        related_name="barbers",
    )
    display_name = models.CharField(_("display name"), max_length=120)
    photo = models.ImageField(
        _("photo"),
        upload_to="barbers/photos/%Y/%m/%d/",
        blank=True,
        null=True,
        help_text=_("Barber profile photo."),
    )
    chair_number = models.PositiveSmallIntegerField(
        _("chair number"),
        unique=True,
        validators=[MinValueValidator(1)],
        help_text=_("Chair number, unique across all shops."),
    )
    rent_type = models.CharField(
        _("rent type"),
        max_length=16,
        choices=RentType.choices,
        default=RentType.FLAT_FEE,
    )
    rent_amount = models.DecimalField(
        _("rent amount"),
        max_digits=8,
        decimal_places=2,
        default=0,
        validators=[MinValueValidator(0)],
        help_text=_("Flat fee or percentage (0-100) for rent."),
    )
    rent_cycle = models.CharField(
        _("rent cycle"),
        max_length=10,
        choices=[("weekly", _("Weekly")), ("monthly", _("Monthly"))],
        default="weekly",
    )
    rent_due_date = models.DateField(
        _("rent due date"),
        null=True,
        blank=True,
        help_text=_("Day of month or week when rent is due."),
    )
    active = models.BooleanField(_("active"), default=True)
    services = models.ManyToManyField(
        Service,
        blank=True,
        verbose_name=_("services offered"),
        related_name="barbers",
        help_text=_(
            "Leave blank to offer every active service. "
            "Select specific services to restrict offerings."
        ),
    )
    stripe_connect_account_id = models.CharField(
        _("Stripe Connect account ID"),
        max_length=50,
        blank=True,
        default="",
        help_text=_("Stripe external account ID from the Connect onboarding flow."),
    )
    stripe_onboarding_status = models.CharField(
        _("Stripe onboarding status"),
        max_length=16,
        choices=BarberStatus.choices,
        default=BarberStatus.NOT_STARTED,
        help_text=_("Tracks Stripe Connect Express onboarding progress."),
    )
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)
    updated_at = models.DateTimeField(_("updated at"), auto_now=True)

    class Meta:
        verbose_name = _("barber")
        verbose_name_plural = _("barbers")
        ordering = ("chair_number",)

    def __str__(self):
        return self.display_name

    def save(
        self,
        force_insert=False,
        force_update=False,
        using=None,
        update_fields=None,
    ):
        self.full_clean()
        super().save(
            force_insert=force_insert,
            force_update=force_update,
            using=using,
            update_fields=update_fields,
        )

    @property
    def offered_services(self):
        """Return the services this barber offers.

        If the ``services`` M2M is empty (no specific services selected),
        returns **all** active services from the catalogue.  Otherwise returns
        only the services explicitly linked to this barber.
        """
        if self.services.exists():
            return self.services.filter(active=True)
        return Service.objects.filter(active=True)

    @property
    def can_accept_card_payments(self):
        """Return True only when Stripe onboarding is complete."""
        return self.stripe_onboarding_status == BarberStatus.COMPLETE

    def clean(self):
        """Validate that the linked user has role 'barber'."""
        if self.user_id is not None and self.user.role != "barber":
            raise ValidationError(
                {"user": "Barber profile requires a user with role 'barber'."}
            )
