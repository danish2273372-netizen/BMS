"""Admin registration for the discounts app."""

from django.contrib import admin

from .models import Discount, AppliesTo, DiscountType


@admin.register(Discount)
class DiscountAdmin(admin.ModelAdmin):
    """Admin for barbershop discounts."""

    list_display = (
        "name",
        "code",
        "type",
        "value",
        "applies_to",
        "active",
        "usage_count",
        "active_from",
        "active_until",
    )
    list_filter = ("type", "applies_to", "active", "created_by_role")
    search_fields = ("name", "code")
    readonly_fields = ("usage_count",)
    filter_horizontal = ("services",)
    fieldsets = (
        (None, {
            "fields": ("name", "code", "type", "value"),
        }),
        (
            "Scoping",
            {
                "fields": ("applies_to", "services"),
            },
        ),
        (
            "Ownership",
            {
                "fields": ("created_by_role", "created_by"),
            },
        ),
        (
            "Window",
            {
                "fields": ("active_from", "active_until", "active"),
            },
        ),
        (
            "Usage",
            {
                "fields": ("usage_count", "max_uses_per_client"),
            },
        ),
    )

    def has_add_permission(self, request):
        """Only owner/superuser can create discounts."""
        return request.user.is_superuser or request.user.is_owner

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        return False
