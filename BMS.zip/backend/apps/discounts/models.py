"""Discount models for the barbershop management system.

A ``Discount`` represents a promotional price reduction applied to services.
It supports percentage-based and flat-amount discounts, with optional service
scoping, activation windows, and per-client usage limits.
"""

from decimal import ROUND_HALF_UP, Decimal, InvalidOperation

from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _


class DiscountType(models.TextChoices):
    PERCENTAGE = "percentage", _("Percentage")
    FLAT_AMOUNT = "flat_amount", _("Flat amount")


class AppliesTo(models.TextChoices):
    ALL_SERVICES = "all_services", _("All services")
    SPECIFIC_SERVICES = "specific_services", _("Specific services")


class Discount(models.Model):
    """A discount that can be applied to one or more services."""

    name = models.CharField(_("name"), max_length=120)
    code = models.CharField(
        _("code"),
        max_length=30,
        blank=True,
        null=True,
        unique=True,
    )
    type = models.CharField(
        _("type"),
        max_length=15,
        choices=DiscountType.choices,
        default=DiscountType.PERCENTAGE,
    )
    value = models.DecimalField(
        _("value"),
        max_digits=8,
        decimal_places=2,
    )
    applies_to = models.CharField(
        _("applies to"),
        max_length=20,
        choices=AppliesTo.choices,
        default=AppliesTo.ALL_SERVICES,
    )
    services = models.ManyToManyField(
        "catalog.Service",
        blank=True,
        related_name="discounts",
    )
    created_by_role = models.CharField(
        _("created by role"),
        max_length=16,
        choices=(
            ("shop_owner", _("Shop owner")),
            ("barber", _("Barber")),
        ),
        default="barber",
    )
    created_by = models.ForeignKey(
        "accounts.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_discounts",
    )
    active_from = models.DateTimeField(
        _("active from"),
        null=True,
        blank=True,
    )
    active_until = models.DateTimeField(
        _("active until"),
        null=True,
        blank=True,
    )
    active = models.BooleanField(_("active"), default=True)
    usage_count = models.PositiveIntegerField(
        _("usage count"),
        default=0,
    )
    max_uses_per_client = models.PositiveIntegerField(
        _("max uses per client"),
        null=True,
        blank=True,
    )

    class Meta:
        verbose_name = _("discount")
        verbose_name_plural = _("discounts")

    def __str__(self):
        return self.name

    def clean(self):
        """Validate discount constraints before saving."""
        super().clean()

        if self.type == DiscountType.PERCENTAGE and self.value > Decimal("100"):
            raise ValidationError(
                _("Percentage discount value cannot exceed 100."),
                code="percentage_too_large",
            )

        if self.value < 0:
            raise ValidationError(
                _("Discount value cannot be negative."),
                code="negative_value",
            )

        if self.applies_to == AppliesTo.SPECIFIC_SERVICES and self.services.exists():
            pass  # OK
        elif self.applies_to == AppliesTo.SPECIFIC_SERVICES:
            raise ValidationError(
                _("Specific services discount must have at least one service assigned."),
                code="no_services_for_specific",
            )

    def is_valid_at(self, when=None):
        """Return True if this discount is currently active and within its window.

        Args:
            when: A timezone-aware datetime to check against. Defaults to
                  ``timezone.now()``.
        """
        if not self.active:
            return False

        if when is None:
            when = timezone.now()

        if self.active_from and when < self.active_from:
            return False

        if self.active_until and when > self.active_until:
            return False

        return True

    def applies_to_service(self, service):
        """Return True if this discount applies to the given service.

        Args:
            service: A ``catalog.Service`` instance.
        """
        if self.applies_to == AppliesTo.ALL_SERVICES:
            return True

        return self.services.filter(pk=service.pk).exists()
