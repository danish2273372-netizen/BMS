"""Discount calculation engine.

Provides a pure function ``apply_discount`` that computes the final price
after applying a ``Discount`` to a given price.  The function handles
percentage-based and flat-amount discounts, rounds using ``ROUND_HALF_UP``,
and never returns a negative value.
"""

from decimal import ROUND_HALF_UP, Decimal


def apply_discount(price, discount):
    """Apply a discount to a price and return the discounted price.

    Args:
        price: The original price as a ``decimal.Decimal``.
        discount: A ``discounts.models.Discount`` instance.

    Returns:
        The discounted price rounded to 2 decimal places using
        ``ROUND_HALF_UP``. Never returns a value below zero.
    """
    if discount is None or not discount.is_valid_at():
        return price.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) if price else Decimal("0.00")

    if discount.type == "percentage":
        discounted = price - (price * discount.value / Decimal("100"))
    elif discount.type == "flat_amount":
        discounted = price - discount.value
    else:
        discounted = price

    return max(discounted.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP), Decimal("0.00"))
