"""Tests for the discounts app: model validation, validity checks, and the engine."""

from decimal import Decimal
from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError
from django.utils import timezone

from apps.accounts.models import User, UserRole
from apps.catalog.models import Service
from apps.discounts.models import Discount, DiscountType, AppliesTo
from apps.discounts.engine import apply_discount

pytestmark = pytest.mark.django_db


# -- shared data helpers ----------------------------------------------------

# -- model tests ------------------------------------------------------------

def test_percentage_discount_creation():
    discount = Discount.objects.create(
        name="15% off",
        type=DiscountType.PERCENTAGE,
        value=Decimal("15"),
    )
    assert discount.name == "15% off"
    assert discount.type == DiscountType.PERCENTAGE
    assert discount.value == Decimal("15")
    assert discount.active is True


def test_flat_amount_discount_creation():
    discount = Discount.objects.create(
        name="5 off",
        type=DiscountType.FLAT_AMOUNT,
        value=Decimal("5"),
    )
    assert discount.type == DiscountType.FLAT_AMOUNT
    assert discount.value == Decimal("5")


def test_clean_percentage_over_100_raises():
    discount = Discount(
        name="150% off",
        type=DiscountType.PERCENTAGE,
        value=Decimal("150"),
    )
    with pytest.raises(ValidationError):
        discount.full_clean()


def test_clean_negative_value_raises():
    discount = Discount(
        name="negative",
        type=DiscountType.FLAT_AMOUNT,
        value=Decimal("-10"),
    )
    with pytest.raises(ValidationError):
        discount.full_clean()


def test_clean_specific_services_no_services_raises():
    """A discount with specific_services must have at least one service."""
    discount = Discount(
        name="specific but no services",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        applies_to=AppliesTo.SPECIFIC_SERVICES,
    )
    discount.save()
    with pytest.raises(ValidationError):
        discount.full_clean()


def test_clean_specific_services_with_services_passes():
    svc = Service.objects.create(
        name="Service A",
        price=Decimal("10.00"),
        duration_minutes=30,
    )
    d = Discount.objects.create(
        name="specific with services",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        applies_to=AppliesTo.SPECIFIC_SERVICES,
    )
    d.services.add(svc)
    d.full_clean()  # should not raise


def test_is_valid_at_active_returns_true():
    discount = Discount.objects.create(
        name="Active discount",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        active=True,
    )
    assert discount.is_valid_at() is True


def test_is_valid_at_inactive_returns_false():
    discount = Discount.objects.create(
        name="Inactive discount",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        active=False,
    )
    assert discount.is_valid_at() is False


def test_is_valid_at_expired_window_returns_false():
    now = timezone.now()
    discount = Discount.objects.create(
        name="Expired discount",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        active_from=now - timedelta(days=7),
        active_until=now - timedelta(days=1),
    )
    assert discount.is_valid_at() is False


def test_is_valid_at_future_start_returns_false():
    now = timezone.now()
    discount = Discount.objects.create(
        name="Future discount",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        active_from=now + timedelta(days=1),
        active_until=now + timedelta(days=7),
    )
    assert discount.is_valid_at() is False


def test_is_valid_at_within_window_returns_true():
    now = timezone.now()
    discount = Discount.objects.create(
        name="Valid discount",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        active_from=now - timedelta(days=1),
        active_until=now + timedelta(days=1),
    )
    assert discount.is_valid_at() is True


def test_applies_to_all_services():
    svc = Service.objects.create(
        name="Service Z",
        price=Decimal("15.00"),
        duration_minutes=30,
    )
    d = Discount.objects.create(
        name="All services",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        applies_to=AppliesTo.ALL_SERVICES,
    )
    assert d.applies_to_service(svc) is True


def test_applies_to_specific_service():
    svc = Service.objects.create(
        name="Service X",
        price=Decimal("25.00"),
        duration_minutes=30,
    )
    d = Discount.objects.create(
        name="Specific services",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        applies_to=AppliesTo.SPECIFIC_SERVICES,
    )
    d.services.add(svc)
    assert d.applies_to_service(svc) is True


def test_applies_to_specific_service_not_match():
    matched = Service.objects.create(
        name="Service Y",
        price=Decimal("25.00"),
        duration_minutes=30,
    )
    other = Service.objects.create(
        name="Other service",
        price=Decimal("20.00"),
        duration_minutes=20,
    )
    d = Discount.objects.create(
        name="Specific services",
        type=DiscountType.PERCENTAGE,
        value=Decimal("10"),
        applies_to=AppliesTo.SPECIFIC_SERVICES,
    )
    d.services.add(matched)
    assert d.applies_to_service(other) is False


# -- engine (pure function) tests ------------------------------------------

def test_percentage_rounding_35_at_15_pct():
    """35.00 at 15% -> 29.75."""
    mock = _MockDiscount(
        type=DiscountType.PERCENTAGE,
        value=Decimal("15"),
        is_valid=True,
    )
    assert apply_discount(Decimal("35.00"), mock) == Decimal("29.75")


def test_percentage_rounding_half_up():
    """30.00 at 33% -> 20.10."""
    mock = _MockDiscount(
        type=DiscountType.PERCENTAGE,
        value=Decimal("33"),
        is_valid=True,
    )
    assert apply_discount(Decimal("30.00"), mock) == Decimal("20.10")


def test_flat_amount_larger_than_price_clamps_to_zero():
    """Flat 20 off 15 -> 0.00."""
    mock = _MockDiscount(
        type=DiscountType.FLAT_AMOUNT,
        value=Decimal("20"),
        is_valid=True,
    )
    assert apply_discount(Decimal("15.00"), mock) == Decimal("0.00")


def test_flat_amount_exact_price_clamps_to_zero():
    """Flat 10 off 10 -> 0.00."""
    mock = _MockDiscount(
        type=DiscountType.FLAT_AMOUNT,
        value=Decimal("10"),
        is_valid=True,
    )
    assert apply_discount(Decimal("10.00"), mock) == Decimal("0.00")


def test_percentage_of_100_percent_returns_zero():
    """100% off -> 0.00."""
    mock = _MockDiscount(
        type=DiscountType.PERCENTAGE,
        value=Decimal("100"),
        is_valid=True,
    )
    assert apply_discount(Decimal("50.00"), mock) == Decimal("0.00")


def test_apply_discount_expired_returns_original():
    """Expired discount -> price unchanged."""
    mock = _MockDiscount(
        type=DiscountType.PERCENTAGE,
        value=Decimal("20"),
        is_valid=False,
    )
    assert apply_discount(Decimal("100.00"), mock) == Decimal("100.00")


def test_apply_discount_none_discount_returns_original():
    """None discount -> price unchanged."""
    assert apply_discount(Decimal("100.00"), None) == Decimal("100.00")


def test_percentage_zero():
    """0% discount -> price unchanged."""
    mock = _MockDiscount(
        type=DiscountType.PERCENTAGE,
        value=Decimal("0"),
        is_valid=True,
    )
    assert apply_discount(Decimal("50.00"), mock) == Decimal("50.00")


# -- helpers ----------------------------------------------------------------

class _MockDiscount:
    """A minimal mock for ``Discount`` used by pure-engine tests."""

    def __init__(self, type=None, value=None, is_valid=True):
        self.type = type
        self.value = value
        self._is_valid = is_valid

    def is_valid_at(self, when=None):
        return self._is_valid
