"""Admin interface for the appointments app."""

from django.contrib import admin

from apps.barbers.models import Barber

from .models import Appointment, AppointmentService, CreatedVia, Status


def _get_barber_for_request(request):
    """Return the Barber instance linked to the request.user, or None."""
    try:
        return request.user.barber_profile
    except AttributeError:
        return None


@admin.register(Appointment)
class AppointmentAdmin(admin.ModelAdmin):
    """Admin for :class:`~apps.appointments.models.Appointment`."""

    list_display = (
        "reference_number",
        "client",
        "barber",
        "requested_time",
        "status",
        "end_time_display",
        "base_price",
    )
    list_filter = ("status", "barber", "requested_time")
    search_fields = ("reference_number", "client__name", "barber__display_name")
    date_hierarchy = "requested_time"
    readonly_fields = (
        "created_at",
        "updated_at",
        "reference_number",
        "end_time_display",
        "base_price",
    )

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser or request.user.is_owner:
            return qs
        barber = _get_barber_for_request(request)
        if barber:
            return qs.filter(barber=barber)
        return qs.none()

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        if obj is None:
            return _get_barber_for_request(request) is not None
        barber = _get_barber_for_request(request)
        if barber and obj.barber_id == barber.id:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        barber = _get_barber_for_request(request)
        if barber and obj and obj.barber_id == barber.id:
            return True
        return False

    def has_add_permission(self, request):
        if request.user.is_superuser or request.user.is_owner:
            return True
        return False

    def end_time_display(self, obj):
        if obj.pk:
            return obj.end_time
        return None
    end_time_display.short_description = "End time"

    def base_price(self, obj):
        if obj.pk:
            return obj.base_price
        return None
    base_price.short_description = "Base price"

    fieldsets = (
        (
            None,
            {
                "fields": (
                    "reference_number",
                    "client",
                    "barber",
                    "status",
                    "created_via",
                    "requested_time",
                    "end_time_display",
                )
            },
        ),
        (
            "Pricing",
            {
                "fields": (
                    "discount_applied",
                    "final_price",
                )
            },
        ),
        (
            "Notes",
            {"fields": ("notes",)},
        ),
        (
            "Timestamps",
            {
                "fields": ("created_at", "updated_at"),
                "classes": ("collapse",),
            },
        ),
    )


@admin.register(AppointmentService)
class AppointmentServiceAdmin(admin.ModelAdmin):
    """Admin for :class:`~apps.appointments.models.AppointmentService`."""

    list_display = ("appointment", "service", "price_at_booking", "duration_minutes")
    list_filter = ("service",)
    search_fields = ("appointment__reference_number", "service__name")
