"""Comprehensive tests for the appointments app.

Covers:
- reference_number uniqueness / generation
- end_time computation from combined service durations
- overlap rejection for non-cancelled appointments
- final_price calculation with and without a discount
"""

import random

from decimal import Decimal

import pytest
from django.core.exceptions import ValidationError
from django.utils import timezone

from apps.appointments.models import (
    Appointment,
    AppointmentService,
    CreatedVia,
    Status,
)
from apps.barbers.models import Barber
from apps.catalog.models import Service
from apps.clients.models import Client
from apps.core.models import Shop, Weekday
from apps.discounts.models import AppliesTo, Discount, DiscountType
from apps.accounts.models import User

pytestmark = pytest.mark.django_db


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture()
def shop():
    return Shop.objects.create(
        name="Test Shop",
        address_line1="123 Main St",
        city="Springfield",
        state="IL",
        postal_code="62704",
        timezone="UTC",
    )


@pytest.fixture()
def service_a():
    return Service.objects.create(
        name="Haircut",
        price=Decimal("25.00"),
        duration_minutes=30,
    )


@pytest.fixture()
def service_b():
    return Service.objects.create(
        name="Beard trim",
        price=Decimal("15.00"),
        duration_minutes=20,
    )


@pytest.fixture()
def barber(shop):
    user = User.objects.create_user(
        phone="+15551234567",
        full_name="Ada Barber",
        pin="1234",
    )
    barber = Barber.objects.create(
        user=user,
        shop=shop,
        display_name="Ada",
        chair_number=1,
    )
    barber.services.add(*list(Service.objects.all()))
    return barber


@pytest.fixture()
def client():
    return Client.objects.create(
        name="John Customer",
        phone="+15559876543",
    )


@pytest.fixture()
def discount_percentage():
    """50% off all services, active."""
    disc = Discount.objects.create(
        name="Half off",
        code="HALFOFF",
        type=DiscountType.PERCENTAGE,
        value=Decimal("50"),
        applies_to=AppliesTo.ALL_SERVICES,
    )
    return disc


@pytest.fixture()
def discount_flat():
    """$10 off all services, active."""
    disc = Discount.objects.create(
        name="$10 off",
        code="TENOFF",
        type=DiscountType.FLAT_AMOUNT,
        value=Decimal("10"),
        applies_to=AppliesTo.ALL_SERVICES,
    )
    return disc


# ── Helpers ─────────────────────────────────────────────────────────────


def _make_appointment(
    client,
    barber,
    services=None,
    requested_time=None,
    status=Status.BOOKED,
    discount=None,
    reference_number=None,
):
    """Convenience factory: create an Appointment with AppointmentService rows.

    Parameters
    ----------
    client : Client
    barber : Barber
    services : list[Service], optional
    requested_time : datetime, optional
        Defaults to a fixed time 2 hours in the future for predictability.
    status : str, optional
    discount : Discount, optional
    reference_number : str, optional

    Returns
    -------
    Appointment
    """
    now = timezone.now()
    requested_time = requested_time or now.replace(hour=14, minute=0, second=0, microsecond=0)

    if services is None:
        services = list(Service.objects.filter(active=True)[:1])

    apt = Appointment.objects.create(
        client=client,
        barber=barber,
        requested_time=requested_time,
        status=status,
        discount_applied=discount,
        reference_number=reference_number or "ABCDE" + str(random.randint(0, 9)),
    )
    for svc in services:
        AppointmentService.objects.create(
            appointment=apt,
            service=svc,
            price_at_booking=svc.price,
            duration_minutes=svc.duration_minutes,
        )
    return apt


# ── Tests ───────────────────────────────────────────────────────────────


class TestReferenceNumber:
    """reference_number uniqueness and generation."""

    def test_auto_generation(self, client, barber, service_a):
        """A reference number is auto-generated if not provided."""
        apt = _make_appointment(
            client, barber, services=[service_a], reference_number=None
        )
        assert apt.reference_number is not None
        assert len(apt.reference_number) == 6
        assert apt.reference_number.isalnum()

    def test_uniqueness_violation(self, client, barber, service_a):
        """Two appointments cannot share the same reference_number."""
        ref = "A" + "B" * 5  # exactly 6 chars
        _make_appointment(
            client, barber, services=[service_a], reference_number=ref
        )
        from django.db import IntegrityError
        apt = Appointment(
            client=client, barber=barber,
            requested_time=timezone.now().replace(hour=15, minute=0, second=0, microsecond=0),
        )
        apt.reference_number = ref
        with pytest.raises((IntegrityError, ValidationError)):
            apt.save()

    def test_unique_in_database(self, client, barber, service_a):
        """The unique constraint prevents duplicates at the DB level."""
        ref = "Z" * 6
        _make_appointment(
            client, barber, services=[service_a], reference_number=ref
        )
        from django.db import IntegrityError
        apt2 = Appointment(
            client=client, barber=barber,
            requested_time=timezone.now().replace(hour=16, minute=0, second=0, microsecond=0),
        )
        apt2.reference_number = ref
        with pytest.raises((IntegrityError, ValidationError)):
            apt2.save()


class TestEndTimeComputation:
    """end_time is correctly computed from combined service durations."""

    def test_single_service(self, client, barber, service_a):
        """end_time = requested_time + duration of single service."""
        apt = _make_appointment(
            client, barber, services=[service_a]
        )
        expected_end = apt.requested_time + timezone.timedelta(
            minutes=service_a.duration_minutes
        )
        assert apt.end_time == expected_end

    def test_two_services(self, client, barber, service_a, service_b):
        """end_time = requested_time + combined durations."""
        apt = _make_appointment(
            client, barber, services=[service_a, service_b]
        )
        expected_minutes = service_a.duration_minutes + service_b.duration_minutes
        expected_end = apt.requested_time + timezone.timedelta(minutes=expected_minutes)
        assert apt.end_time == expected_end

    def test_multiple_services(self, client, barber, service_a, service_b):
        """Three services: durations are summed correctly."""
        extra = Service.objects.create(name="Shave", price=Decimal("10.00"), duration_minutes=15)
        apt = _make_appointment(
            client, barber, services=[service_a, service_b, extra]
        )
        expected_minutes = service_a.duration_minutes + service_b.duration_minutes + extra.duration_minutes
        expected_end = apt.requested_time + timezone.timedelta(minutes=expected_minutes)
        assert apt.end_time == expected_end


class TestOverlapRejection:
    """Overlapping non-cancelled appointments for the same barber are rejected."""

    def test_overlap_rejected(self, client, barber, service_a):
        """Two bookings at overlapping times for the same barber fail on clean."""
        start = timezone.now().replace(hour=10, minute=0, second=0, microsecond=0)
        _make_appointment(
            client, barber, services=[service_a], requested_time=start
        )
        # Overlapping: starts 15 minutes into the first appointment
        apt2 = Appointment(
            client=client,
            barber=barber,
            requested_time=start + timezone.timedelta(minutes=15),
        )
        with pytest.raises(ValidationError, match="overlapping"):
            apt2.clean()

    def test_adjacent_is_ok(self, client, barber, service_a):
        """Touching (non-overlapping) appointments are allowed."""
        start = timezone.now().replace(hour=10, minute=0, second=0, microsecond=0)
        _make_appointment(
            client, barber, services=[service_a], requested_time=start
        )
        # Exact end of first appointment
        apt2 = Appointment(
            client=client,
            barber=barber,
            requested_time=start + timezone.timedelta(minutes=service_a.duration_minutes),
        )
        apt2.full_clean()  # should not raise

    def test_different_barbers_ok(self, client, shop, service_a):
        """Same time, different barbers is fine."""
        user1 = User.objects.create_user(
            phone="+15551234568", full_name="Barber One", pin="1234"
        )
        user2 = User.objects.create_user(
            phone="+15551234569", full_name="Barber Two", pin="5678"
        )
        barber1 = Barber.objects.create(user=user1, shop=shop, display_name="One", chair_number=2)
        barber2 = Barber.objects.create(user=user2, shop=shop, display_name="Two", chair_number=3)

        start = timezone.now().replace(hour=10, minute=0, second=0, microsecond=0)
        _make_appointment(
            client, barber1, services=[service_a], requested_time=start
        )
        apt2 = Appointment(
            client=client,
            barber=barber2,
            requested_time=start,
        )
        apt2.full_clean()

    def test_cancelled_not_overlapped(self, client, barber, service_a):
        """A cancelled appointment does not block a new one."""
        start = timezone.now().replace(hour=10, minute=0, second=0, microsecond=0)
        _make_appointment(
            client, barber, services=[service_a], requested_time=start, status=Status.CANCELLED
        )
        # Same slot should be allowed because apt1 is cancelled
        apt2 = Appointment(
            client=client,
            barber=barber,
            requested_time=start + timezone.timedelta(minutes=15),
        )
        apt2.full_clean()

    def test_no_show_not_overlapped(self, client, barber, service_a):
        """A no_show appointment does not block a new one."""
        start = timezone.now().replace(hour=10, minute=0, second=0, microsecond=0)
        _make_appointment(
            client, barber, services=[service_a], requested_time=start, status=Status.NO_SHOW
        )
        apt2 = Appointment(
            client=client,
            barber=barber,
            requested_time=start + timezone.timedelta(minutes=15),
        )
        apt2.full_clean()


class TestFinalPrice:
    """final_price calculation with and without a discount."""

    def test_no_discount(self, client, barber, service_a, service_b):
        """Without a discount, final_price equals base_price."""
        apt = _make_appointment(
            client, barber, services=[service_a, service_b]
        )
        result = apt.calculate_final_price()
        assert result == apt.base_price
        assert apt.final_price == apt.base_price

    def test_percentage_discount(self, client, barber, service_a, service_b, discount_percentage):
        """50% discount halves the final_price."""
        apt = _make_appointment(
            client, barber, services=[service_a, service_b], discount=discount_percentage
        )
        result = apt.calculate_final_price()
        expected = (service_a.price + service_b.price) / 2
        assert result == expected.quantize(Decimal("0.01"))

    def test_flat_discount(self, client, barber, service_a, discount_flat):
        """$10 flat discount subtracts from base."""
        apt = _make_appointment(
            client, barber, services=[service_a], discount=discount_flat
        )
        result = apt.calculate_final_price()
        expected = max(service_a.price - discount_flat.value, Decimal("0"))
        assert result == expected.quantize(Decimal("0.01"))

    def test_discount_not_valid(self, client, barber, service_a):
        """Inactive discount leaves final_price at base_price."""
        disc = Discount.objects.create(
            name="Expired",
            type=DiscountType.FLAT_AMOUNT,
            value=Decimal("10"),
            applies_to=AppliesTo.ALL_SERVICES,
            active=False,
        )
        apt = _make_appointment(
            client, barber, services=[service_a], discount=disc
        )
        result = apt.calculate_final_price()
        assert result == apt.base_price

    def test_discount_zero_floor(self, client, barber, service_a):
        """Discount never pushes final_price below zero."""
        disc = Discount.objects.create(
            name="Huge discount",
            type=DiscountType.FLAT_AMOUNT,
            value=Decimal("99999"),
            applies_to=AppliesTo.ALL_SERVICES,
        )
        apt = _make_appointment(
            client, barber, services=[service_a], discount=disc
        )
        result = apt.calculate_final_price()
        assert result == Decimal("0.00")

    def test_base_price_property(self, client, barber, service_a, service_b):
        """base_price is the sum of AppointmentService prices."""
        apt = _make_appointment(
            client, barber, services=[service_a, service_b]
        )
        assert apt.base_price == service_a.price + service_b.price
