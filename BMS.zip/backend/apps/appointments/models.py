"""Appointment and service-combo models for the barbershop system.

An ``Appointment`` represents a scheduled service session.  Each appointment
may bundle multiple services (e.g. haircut + beard trim) via the
``AppointmentService`` through model which captures the price-at-booking and
the actual duration so that the ``requested_time`` window is correctly sized
and the final charge is accurate even if catalogue prices change.
"""

import string
import random

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

from apps.catalog.models import Service

User = get_user_model()


class CreatedVia(models.TextChoices):
    """How the appointment was created."""

    WHATSAPP = "whatsapp", _("WhatsApp")
    WEB = "web", _("Web")
    MANUAL = "manual", _("Manual")


class Status(models.TextChoices):
    """Appointment status lifecycle."""

    BOOKED = "booked", _("Booked")
    IN_PROGRESS = "in_progress", _("In progress")
    COMPLETED = "completed", _("Completed")
    PAID = "paid", _("Paid")
    NO_SHOW = "no_show", _("No show")
    CANCELLED = "cancelled", _("Cancelled")


class AppointmentService(models.Model):
    """Through model capturing a single service within an appointment bundle."""

    appointment = models.ForeignKey(
        "Appointment",
        on_delete=models.CASCADE,
        verbose_name=_("appointment"),
        related_name="appointment_services",
    )
    service = models.ForeignKey(
        Service,
        on_delete=models.PROTECT,
        verbose_name=_("service"),
    )
    price_at_booking = models.DecimalField(
        _("price at booking"),
        max_digits=8,
        decimal_places=2,
    )
    duration_minutes = models.PositiveIntegerField(
        _("duration (minutes)"),
    )

    class Meta:
        verbose_name = _("appointment service")
        verbose_name_plural = _("appointment services")

    def __str__(self):
        return f"{self.appointment.reference_number} - {self.service.name}"


# ---------------------------------------------------------------------------
# Managers / QuerySets
# ---------------------------------------------------------------------------


class AppointmentQuerySet(models.QuerySet):
    """Custom queryset providing overlap-aware managers."""

    def active(self):
        """Return appointments that are not cancelled or completed/paid/no_show."""
        return self.exclude(
            status__in=[
                Status.CANCELLED,
                Status.COMPLETED,
                Status.PAID,
                Status.NO_SHOW,
            ]
        )


class AppointmentManager(models.Manager):
    """Manager that rejects overlapping non-cancelled bookings."""

    use_in_migrations = True

    def get_queryset(self):
        return AppointmentQuerySet(self.model, using=self._db)

    def active(self):
        return self.get_queryset().active()


def _generate_reference():
    """Generate a 6-character uppercase alphanumeric reference number."""
    chars = string.ascii_uppercase + string.digits
    while True:
        ref = "".join(random.choices(chars, k=6))
        if not Appointment.objects.filter(reference_number=ref).exists():
            return ref


# ---------------------------------------------------------------------------
# Core model
# ---------------------------------------------------------------------------


class Appointment(models.Model):
    """A scheduled service session for a client with a barber."""

    client = models.ForeignKey(
        "clients.Client",
        on_delete=models.CASCADE,
        verbose_name=_("client"),
        related_name="appointments",
    )
    barber = models.ForeignKey(
        "barbers.Barber",
        on_delete=models.CASCADE,
        verbose_name=_("barber"),
        related_name="appointments",
    )
    services = models.ManyToManyField(
        Service,
        through="AppointmentService",
        related_name="appointments",
        verbose_name=_("services"),
    )
    requested_time = models.DateTimeField(
        _("requested time"),
        help_text=_("The datetime the client requested the appointment for."),
    )
    status = models.CharField(
        _("status"),
        max_length=12,
        choices=Status.choices,
        default=Status.BOOKED,
    )
    created_via = models.CharField(
        _("created via"),
        max_length=12,
        choices=CreatedVia.choices,
        default="web",
    )
    discount_applied = models.ForeignKey(
        "discounts.Discount",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("discount applied"),
    )
    final_price = models.DecimalField(
        _("final price"),
        max_digits=8,
        decimal_places=2,
        null=True,
        blank=True,
    )
    reference_number = models.CharField(
        _("reference number"),
        max_length=6,
        unique=True,
        blank=True,
        default="",
    )
    notes = models.TextField(
        _("notes"),
        blank=True,
        default="",
    )
    created_at = models.DateTimeField(
        _("created at"),
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        _("updated at"),
        auto_now=True,
    )

    _end_time_cache = None

    objects = AppointmentManager()

    class Meta:
        verbose_name = _("appointment")
        verbose_name_plural = _("appointments")
        ordering = ("requested_time",)

    def __str__(self):
        return f"{self.reference_number} - {self.client.name} / {self.barber}"

    def save(self, *args, **kwargs):
        """Generate reference_number if not yet set, then persist."""
        if not self.reference_number:
            self.reference_number = _generate_reference()
        super().save(*args, **kwargs)
        self._set_end_time()

    @property
    def base_price(self):
        """Sum of all :class:`AppointmentService.price_at_booking` values."""
        if self.pk is None:
            return Decimal("0.00")
        total = sum(
            asvc.price_at_booking for asvc in self.appointment_services.all()
        )
        return total.quantize(Decimal("0.01"))

    @property
    def end_time(self):
        """Computed end time: ``requested_time`` plus total duration minutes."""
        if self.pk is None:
            return self.requested_time
        total_minutes = sum(
            asvc.duration_minutes for asvc in self.appointment_services.all()
        )
        return self.requested_time + timezone.timedelta(minutes=total_minutes)

    def _set_end_time(self):
        """Recalculate and cache end_time based on current appointment services."""
        if self.pk is None:
            self._end_time_cache = self.requested_time
            return
        total_minutes = sum(
            asvc.duration_minutes for asvc in self.appointment_services.all()
        )
        self._end_time_cache = self.requested_time + timezone.timedelta(
            minutes=total_minutes
        )

    def calculate_final_price(self, discount=None):
        """Apply a discount and store the result in ``final_price``.

        Parameters
        ----------
        discount : discounts.Discount, optional
            Discount to apply.  If ``None``, the appointment's existing
            ``discount_applied`` is used.

        Returns
        -------
        Decimal
            The computed final price.
        """
        base = self.base_price
        if discount is None:
            discount = self.discount_applied

        if discount is not None and discount.is_valid_at():
            if discount.type == "percentage":
                reduction = base * discount.value / Decimal("100")
                final = base - reduction
            else:
                final = base - discount.value
            final = max(final, Decimal("0"))
        else:
            final = base

        self.final_price = final.quantize(Decimal("0.01"))
        return self.final_price

    def clean(self):
        """Validate the appointment before saving.

        - Rejects overlapping non-cancelled appointments for the same barber.
        - Ensures at least one service is attached (only on existing instances).
        """
        if self.pk and not self.services.exists():
            raise ValidationError(
                _("An appointment must have at least one service."),
                code="requires_service",
            )

        def _end_time_from_appointment(apt):
            """Compute end_time for an appointment instance."""
            total = 0
            for asvc in apt.appointment_services.all():
                total += asvc.duration_minutes
            return apt.requested_time + timezone.timedelta(minutes=total)

        qs = (
            Appointment.objects.active()
            .filter(barber=self.barber, status__in=[Status.BOOKED, Status.IN_PROGRESS])
        )
        if self.pk:
            qs = qs.exclude(pk=self.pk)

        my_end = self.end_time
        for other in qs:
            other_end = _end_time_from_appointment(other)
            # Two intervals overlap if one starts before the other ends
            # and the other starts before this one ends
            if other.requested_time < my_end and self.requested_time < other_end:
                raise ValidationError(
                    _(
                        "Barber {barber} already has a booking overlapping "
                        "with {start} - {end}."
                    ).format(
                        barber=self.barber,
                        start=self.requested_time.isoformat(),
                        end=my_end.isoformat(),
                    ),
                    code="overlap",
                )
