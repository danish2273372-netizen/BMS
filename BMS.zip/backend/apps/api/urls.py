from django.db import models
from django.urls import path

from . import views

urlpatterns = [
    path("auth/login/", views.LoginView.as_view(), name="login"),
    path("auth/refresh/", views.RefreshView.as_view(), name="token_refresh"),
    path("appointments/today/", views.TodaysAppointmentsView.as_view(), name="appointments-today"),
    path("appointments/", views.AppointmentsView.as_view(), name="appointments-list"),
    path(
        "appointments/by-reference/<str:reference_number>/",
        views.AppointmentByReferenceView.as_view(),
        name="appointment-by-reference",
    ),
    path(
        "appointments/<int:id>/",
        views.AppointmentRetrieveView.as_view(),
        name="appointment-detail",
    ),
    path(
        "appointments/<int:id>/complete/",
        views.CompleteAppointmentView.as_view(),
        name="appointment-complete",
    ),
    path(
        "appointments/<int:id>/mark-paid-cash/",
        views.MarkPaidCashView.as_view(),
        name="appointment-mark-paid-cash",
    ),
    path("me/", views.MeView.as_view(), name="me"),
    path("earnings/", views.EarningsView.as_view(), name="earnings"),
]
