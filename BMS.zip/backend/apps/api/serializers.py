from decimal import Decimal

from rest_framework import serializers
from django.contrib.auth import get_user_model
from django.utils import timezone

from apps.appointments.models import Appointment, Status

User = get_user_model()


class LoginSerializer(serializers.Serializer):
    """Validate a phone + PIN pair and return the matching user."""

    phone = serializers.CharField()
    pin = serializers.CharField()

    def validate(self, attrs):
        phone = attrs.get("phone")
        pin = attrs.get("pin")
        user = User.objects.filter(phone=phone).first()
        if user and user.check_pin(pin):
            return user
        raise serializers.ValidationError("Invalid credentials")


class AppointmentSerializer(serializers.ModelSerializer):
    """Barber-facing view of an appointment."""

    client_name = serializers.CharField(source="client.name", read_only=True)
    client_phone = serializers.CharField(source="client.phone", read_only=True)
    services_detail = serializers.SerializerMethodField()
    base_price = serializers.SerializerMethodField()

    class Meta:
        model = Appointment
        fields = (
            "id",
            "reference_number",
            "client_name",
            "client_phone",
            "requested_time",
            "status",
            "created_via",
            "notes",
            "final_price",
            "base_price",
            "services_detail",
        )

    def get_services_detail(self, obj):
        return [
            {
                "name": asvc.service.name,
                "price": str(asvc.price_at_booking),
                "duration_minutes": asvc.duration_minutes,
            }
            for asvc in obj.appointment_services.all()
        ]

    def get_base_price(self, obj):
        return str(obj.base_price)
