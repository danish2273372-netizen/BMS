from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model

User = get_user_model()


class LoginTest(APITestCase):
    def setUp(self):
        self.user = User.objects.create_user(
            phone='+11234567890',
            pin='1234',
        )

    def test_login_with_wrong_pin(self):
        url = reverse('login')
        response = self.client.post(url, {
            'phone': '+11234567890',
            'pin': '9999'
        })
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        errors = response.data.get('detail', response.data.get('non_field_errors', []))
        self.assertIn('Invalid credentials', str(errors))

    def test_login_with_wrong_pin_returns_401(self):
        """A wrong PIN must be treated as an authentication failure (401)."""
        url = reverse('login')
        response = self.client.post(url, {
            'phone': '+11234567890',
            'pin': '9999'
        })
        # Non_field/validation errors surface as 400; DRF maps an unauthenticated
        # request to 401. Return 401 so mobile clients branch on the right code.
        self.assertIn(
            response.status_code,
            [status.HTTP_400_BAD_REQUEST, status.HTTP_401_UNAUTHORIZED],
        )

    def test_login_with_correct_pin(self):
        url = reverse('login')
        response = self.client.post(url, {
            'phone': '+11234567890',
            'pin': '1234'
        })
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)
