"""Tests for the earnings endpoint (card vs cash split)."""

from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from apps.appointments.models import Appointment, AppointmentService, Status
from apps.barbers.models import Barber
from apps.catalog.models import Service
from apps.clients.models import Client
from apps.core.models import Shop
from apps.payments.models import Payment, PaymentMethod, PaymentStatus

User = get_user_model()


class EarningsTest(APITestCase):
    def setUp(self):
        self.shop = Shop.objects.create(
            name="Test Shop",
            address_line1="123 Main St",
            city="Springfield",
            state="IL",
            postal_code="62704",
            timezone="UTC",
        )
        self.barber_user = User.objects.create_user(
            phone="+15551234567", full_name="Ada", pin="1234"
        )
        self.barber = Barber.objects.create(
            user=self.barber_user,
            shop=self.shop,
            display_name="Ada",
            chair_number=1,
        )
        self.client = self.client_class()
        self.client.force_authenticate(user=self.barber_user)

        self.client_a = Client.objects.create(name="John", phone="+15559876543")
        self.service = Service.objects.create(
            name="Haircut", price=Decimal("25.00"), duration_minutes=30
        )

        self.now = timezone.now()

    def _appointment(self, status=Status.COMPLETED, final=Decimal("25.00")):
        from string import ascii_uppercase
        import random
        apt = Appointment.objects.create(
            client=self.client_a,
            barber=self.barber,
            requested_time=self.now,
            status=status,
            final_price=final,
            reference_number="".join(random.choices(ascii_uppercase, k=6)),
        )
        AppointmentService.objects.create(
            appointment=apt,
            service=self.service,
            price_at_booking=self.service.price,
            duration_minutes=self.service.duration_minutes,
        )
        return apt

    def _payment(self, appointment, method, amount):
        return Payment.objects.create(
            appointment=appointment,
            barber=self.barber,
            amount=amount,
            payment_method=method,
            status=PaymentStatus.PAID,
            paid_at=self.now,
        )

    def test_earnings_splits_card_vs_cash(self):
        apt_cash = self._appointment(final=Decimal("25.00"))
        self._payment(apt_cash, PaymentMethod.CASH, Decimal("25.00"))

        apt_card = self._appointment(final=Decimal("50.00"))
        self._payment(apt_card, PaymentMethod.CARD_LINK, Decimal("50.00"))

        url = reverse("earnings")
        response = self.client.get(url, {"period": "today"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        data = response.data
        self.assertEqual(Decimal(data["cash_total"]), Decimal("25.00"))
        self.assertEqual(Decimal(data["card_total"]), Decimal("50.00"))
        self.assertEqual(Decimal(data["combined_total"]), Decimal("75.00"))
        self.assertEqual(
            Decimal(data["withdrawable_balance"]), Decimal("75.00")
        )

    def test_earnings_ignore_unpaid_payments(self):
        apt = self._appointment()
        Payment.objects.create(
            appointment=apt,
            barber=self.barber,
            amount=Decimal("25.00"),
            payment_method=PaymentMethod.CASH,
            status=PaymentStatus.PENDING,
            paid_at=None,
        )
        url = reverse("earnings")
        response = self.client.get(url, {"period": "today"})
        self.assertEqual(
            Decimal(response.data["cash_total"]), Decimal("0.00")
        )
