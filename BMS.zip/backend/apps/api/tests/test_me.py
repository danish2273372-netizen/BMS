"""Tests for the barber profile (/me) and auth refresh endpoints."""

from django.contrib.auth import get_user_model
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from apps.barbers.models import Barber, BarberStatus
from apps.core.models import Shop

User = get_user_model()


class MeTest(APITestCase):
    def setUp(self):
        self.shop = Shop.objects.create(
            name="Test Shop",
            address_line1="123 Main St",
            city="Springfield",
            state="IL",
            postal_code="62704",
            timezone="UTC",
        )
        self.barber_user = User.objects.create_user(
            phone="+15551234567", full_name="Ada", pin="1234"
        )
        self.barber = Barber.objects.create(
            user=self.barber_user,
            shop=self.shop,
            display_name="Ada",
            chair_number=1,
            stripe_onboarding_status=BarberStatus.NOT_STARTED,
        )
        self.client.force_authenticate(user=self.barber_user)

    def test_me_returns_profile_and_stripe_status(self):
        url = reverse("me")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.data
        self.assertEqual(data["display_name"], "Ada")
        self.assertEqual(data["phone"], "+15551234567")
        self.assertEqual(data["stripe"]["onboarding_status"], "not_started")
        self.assertFalse(data["stripe"]["can_accept_card_payments"])
        self.assertEqual(data["shop"]["name"], "Test Shop")
        self.assertEqual(data["rent"]["type"], "flat_fee")

    def test_me_requires_barber(self):
        owner = User.objects.create_user(
            phone="+15559999999", full_name="Owner", pin="9999", role="owner"
        )
        self.client.force_authenticate(user=owner)
        url = reverse("me")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_403_FORBIDDEN)
