"""Tests for the barber mobile API (apps/api)."""

from datetime import timedelta
from decimal import Decimal

from django.contrib.auth import get_user_model
from django.urls import reverse
from django.utils import timezone
from rest_framework import status
from rest_framework.test import APITestCase

from apps.appointments.models import Appointment, AppointmentService, Status
from apps.barbers.models import Barber
from apps.catalog.models import Service
from apps.clients.models import Client
from apps.core.models import Shop
from apps.payments.models import Payment, PaymentMethod, PaymentStatus

User = get_user_model()


class BarberAPITestCase(APITestCase):
    """Shared setup: a shop, two barbers, two clients and appointments."""

    def setUp(self):
        self.shop = Shop.objects.create(
            name="Test Shop",
            address_line1="123 Main St",
            city="Springfield",
            state="IL",
            postal_code="62704",
            timezone="UTC",
        )

        self.barber_user = User.objects.create_user(
            phone="+15551234567", full_name="Ada", pin="1234"
        )
        self.barber = Barber.objects.create(
            user=self.barber_user,
            shop=self.shop,
            display_name="Ada",
            chair_number=1,
        )

        self.other_barber_user = User.objects.create_user(
            phone="+15557654321", full_name="Bob", pin="1111"
        )
        self.other_barber = Barber.objects.create(
            user=self.other_barber_user,
            shop=self.shop,
            display_name="Bob",
            chair_number=2,
        )

        self.client_a = Client.objects.create(
            name="John", phone="+15559876543"
        )
        self.client_b = Client.objects.create(
            name="Jane", phone="+15554443322"
        )

        self.service = Service.objects.create(
            name="Haircut", price=Decimal("25.00"), duration_minutes=30
        )

        self.appointment = self._make_appointment(
            self.barber, self.client_a, "AAAAAA"
        )
        self.other_appointment = self._make_appointment(
            self.other_barber, self.client_b, "BBBBBB"
        )

        self.client.force_authenticate(user=self.barber_user)

    def _make_appointment(self, barber, client, reference_number, status=Status.BOOKED):
        apt = Appointment.objects.create(
            client=client,
            barber=barber,
            requested_time=timezone.now() + timedelta(hours=1),
            status=status,
            reference_number=reference_number,
        )
        AppointmentService.objects.create(
            appointment=apt,
            service=self.service,
            price_at_booking=self.service.price,
            duration_minutes=self.service.duration_minutes,
        )
        return apt

    def _force_auth(self, user):
        self.client.force_authenticate(user=user)


class AppointmentScopingTest(BarberAPITestCase):
    def test_barber_a_gets_404_for_barber_b_appointment(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-detail", kwargs={"id": self.other_appointment.id}
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_barber_a_gets_404_for_barber_b_by_reference(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-by-reference",
            kwargs={"reference_number": self.other_appointment.reference_number},
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_complete_barber_b_appointment_returns_404(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-complete", kwargs={"id": self.other_appointment.id}
        )
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_barber_can_read_own_appointment(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-detail", kwargs={"id": self.appointment.id}
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(
            response.data["reference_number"], self.appointment.reference_number
        )


class TodayAndListTest(BarberAPITestCase):
    def test_today_returns_only_own_appointments(self):
        self._force_auth(self.barber_user)
        url = reverse("appointments-today")
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        refs = {a["reference_number"] for a in response.data}
        self.assertIn("AAAAAA", refs)
        self.assertNotIn("BBBBBB", refs)

    def test_list_filters_by_status(self):
        self._force_auth(self.barber_user)
        url = reverse("appointments-list")
        response = self.client.get(url, {"status": "booked"})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertTrue(all(a["status"] == "booked" for a in response.data))


class MarkPaidCashTest(BarberAPITestCase):
    def test_mark_paid_cash_is_idempotent(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-mark-paid-cash", kwargs={"id": self.appointment.id}
        )
        resp1 = self.client.post(url)
        self.assertEqual(resp1.status_code, status.HTTP_200_OK)

        payment = Payment.objects.get(appointment=self.appointment)
        self.assertEqual(payment.payment_method, PaymentMethod.CASH)
        self.assertEqual(payment.marked_by, self.barber_user)
        self.assertEqual(payment.status, PaymentStatus.PAID)

        self.appointment.refresh_from_db()
        self.client_a.refresh_from_db()
        visits_after_first = self.client_a.total_visits

        # Second call must not create a new payment or double-count visits.
        resp2 = self.client.post(url)
        self.assertEqual(resp2.status_code, status.HTTP_200_OK)
        self.assertEqual(Payment.objects.filter(appointment=self.appointment).count(), 1)
        self.client_a.refresh_from_db()
        self.assertEqual(self.client_a.total_visits, visits_after_first)

    def test_second_call_does_not_double_count_earnings(self):
        today = timezone.now().date()
        self._force_auth(self.barber_user)
        self.appointment.status = Status.COMPLETED
        self.appointment.final_price = Decimal("25.00")
        self.appointment.save()

        mark_url = reverse(
            "appointment-mark-paid-cash", kwargs={"id": self.appointment.id}
        )
        self.client.post(mark_url)

        earnings_url = reverse("earnings")
        resp = self.client.get(
            earnings_url, {"date": today.isoformat()}
        )
        first_cash = Decimal(resp.data["cash_total"])

        self.client.post(mark_url)
        resp = self.client.get(earnings_url, {"date": today.isoformat()})
        self.assertEqual(Decimal(resp.data["cash_total"]), first_cash)


class CompleteAppointmentTest(BarberAPITestCase):
    def test_complete_sets_status_and_final_price(self):
        self._force_auth(self.barber_user)
        url = reverse(
            "appointment-complete", kwargs={"id": self.appointment.id}
        )
        response = self.client.post(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.appointment.refresh_from_db()
        self.assertEqual(self.appointment.status, Status.COMPLETED)
        self.assertEqual(
            self.appointment.final_price, self.appointment.base_price
        )
