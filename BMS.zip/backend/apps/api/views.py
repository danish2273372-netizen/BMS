from datetime import datetime, timedelta
from decimal import Decimal

from django.db import models

from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from rest_framework.permissions import AllowAny, BasePermission
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from apps.appointments.models import Appointment, Status
from apps.discounts.models import Discount
from apps.payments.models import Payment, PaymentMethod, PaymentStatus

from .serializers import AppointmentSerializer, LoginSerializer


class IsBarber(BasePermission):
    """Allow access only to users who are barbers and have a barber profile."""

    def has_permission(self, request, view):
        return (
            request.user
            and request.user.is_authenticated
            and request.user.is_barber
            and hasattr(request.user, "barber_profile")
        )


class LoginView(APIView):
    permission_classes = [AllowAny]
    authentication_classes = []

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data
        refresh = RefreshToken.for_user(user)
        return Response(
            {
                "access": str(refresh.access_token),
                "refresh": str(refresh),
            },
            status=status.HTTP_200_OK,
        )


class RefreshView(TokenRefreshView):
    pass


class BarberScopedAppointmentsMixin:
    """Scope every appointment lookup to the logged-in barber."""

    def get_barber(self, request):
        return request.user.barber_profile

    def get_queryset(self, request):
        return Appointment.objects.filter(barber=self.get_barber(request))


class AppointmentsView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def get(self, request):
        """List appointments, optionally filtered by date and/or status."""
        qs = self.get_queryset(request).select_related("client", "barber")

        date_param = request.query_params.get("date")
        status_param = request.query_params.get("status")

        if date_param:
            try:
                day = datetime.strptime(date_param, "%Y-%m-%d").date()
            except ValueError:
                return Response(
                    {"detail": "date must be in YYYY-MM-DD format."},
                    status=status.HTTP_400_BAD_REQUEST,
                )
            start = timezone_datetime(day)
            end = start + timedelta(days=1)
            qs = qs.filter(requested_time__gte=start, requested_time__lt=end)

        if status_param:
            qs = qs.filter(status=status_param)

        serializer = AppointmentSerializer(qs, many=True)
        return Response(serializer.data)


class TodaysAppointmentsView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def get(self, request):
        qs = self.get_queryset(request)
        now = timezone_now()
        start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = start + timedelta(days=1)
        qs = qs.filter(requested_time__gte=start, requested_time__lt=end)
        serializer = AppointmentSerializer(qs, many=True)
        return Response(serializer.data)


class AppointmentByReferenceView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def get(self, request, reference_number):
        try:
            appointment = self.get_queryset(request).get(
                reference_number=reference_number
            )
        except Appointment.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = AppointmentSerializer(appointment)
        return Response(serializer.data)


class AppointmentRetrieveView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def get(self, request, id):
        try:
            appointment = self.get_queryset(request).get(id=id)
        except Appointment.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)
        serializer = AppointmentSerializer(appointment)
        return Response(serializer.data)


class CompleteAppointmentView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def post(self, request, id):
        try:
            appointment = self.get_queryset(request).get(id=id)
        except Appointment.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        discount = None
        discount_id = request.data.get("discount_id")
        if discount_id:
            try:
                discount = Discount.objects.get(pk=discount_id)
            except Discount.DoesNotExist:
                discount = None

        appointment.status = Status.COMPLETED
        appointment.final_price = appointment.calculate_final_price(discount=discount)
        if discount is not None:
            appointment.discount_applied = discount
        appointment.save()

        serializer = AppointmentSerializer(appointment)
        return Response(serializer.data)


class MarkPaidCashView(APIView, BarberScopedAppointmentsMixin):
    permission_classes = [IsBarber]

    def post(self, request, id):
        try:
            appointment = self.get_queryset(request).get(id=id)
        except Appointment.DoesNotExist:
            return Response(status=status.HTTP_404_NOT_FOUND)

        amount = appointment.final_price or appointment.base_price
        payment, created = Payment.objects.get_or_create(
            appointment=appointment,
            defaults={
                "barber": appointment.barber,
                "amount": amount,
                "payment_method": PaymentMethod.CASH,
                "status": PaymentStatus.PENDING,
            },
        )
        # Record the cash payment exactly once. Payment.mark_paid is
        # idempotent — a second call is a no-op and does not double count.
        payment.mark_paid(by=request.user)

        serializer = AppointmentSerializer(appointment)
        return Response(serializer.data)


class MeView(APIView):
    permission_classes = [IsBarber]

    def get(self, request):
        barber = request.user.barber_profile
        # Latest rent payment status for this barber.
        rent_payment = barber.rent_payments.order_by("-period_start").first()
        return Response(
            {
                "id": barber.id,
                "display_name": barber.display_name,
                "phone": request.user.phone,
                "chair_number": barber.chair_number,
                "shop": {
                    "id": barber.shop_id,
                    "name": barber.shop.name,
                },
                "rent": {
                    "type": barber.rent_type,
                    "amount": str(barber.rent_amount),
                    "cycle": barber.rent_cycle,
                    "due_date": barber.rent_due_date,
                    "current_period": (
                        {
                            "period_label": rent_payment.period_label,
                            "paid": rent_payment.paid,
                        }
                        if rent_payment
                        else None
                    ),
                },
                "stripe": {
                    "onboarding_status": barber.stripe_onboarding_status,
                    "can_accept_card_payments": barber.can_accept_card_payments,
                },
                "active": barber.active,
            }
        )


class EarningsView(APIView):
    permission_classes = [IsBarber]

    def get(self, request):
        barber = request.user.barber_profile
        period = request.query_params.get("period", "today")

        now = timezone_now()
        if period == "week":
            start = now - timedelta(days=now.weekday())
            start = start.replace(hour=0, minute=0, second=0, microsecond=0)
        elif period == "month":
            start = now.replace(
                day=1, hour=0, minute=0, second=0, microsecond=0
            )
        else:  # today
            start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        end = now

        qs = Payment.objects.filter(
            barber=barber,
            status=PaymentStatus.PAID,
            paid_at__gte=start,
            paid_at__lte=end,
        )

        totals = qs.aggregate(
            card_total=models.Sum(
                "amount",
                filter=models.Q(payment_method=PaymentMethod.CARD_LINK),
                default=Decimal("0"),
            ),
            cash_total=models.Sum(
                "amount",
                filter=models.Q(payment_method=PaymentMethod.CASH),
                default=Decimal("0"),
            ),
            in_person_card_total=models.Sum(
                "amount",
                filter=models.Q(payment_method=PaymentMethod.IN_PERSON_CARD),
                default=Decimal("0"),
            ),
        )

        card_total = totals["card_total"] or Decimal("0")
        cash_total = totals["cash_total"] or Decimal("0")
        in_person_card_total = totals["in_person_card_total"] or Decimal("0")
        combined_total = card_total + cash_total + in_person_card_total

        # Withdrawable balance = combined total anticipated minus any future
        # withholding; for this step report the combined total.
        withdrawable_balance = combined_total

        return Response(
            {
                "period": period,
                "card_total": str(card_total),
                "cash_total": str(cash_total),
                "in_person_card_total": str(in_person_card_total),
                "combined_total": str(combined_total),
                "withdrawable_balance": str(withdrawable_balance),
            }
        )


# --- helpers -------------------------------------------------------------


def timezone_now():
    from django.utils import timezone

    return timezone.now()


def timezone_datetime(day):
    import datetime as _dt

    from django.utils import timezone

    return timezone.make_aware(_dt.datetime.combine(day, _dt.time.min))
