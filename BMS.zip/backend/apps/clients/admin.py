"""Admin registration for the clients app."""

from django.contrib import admin

from .models import Client


@admin.register(Client)
class ClientAdmin(admin.ModelAdmin):
    """Admin for barbershop clients."""

    list_display = ("name", "phone", "total_visits", "first_visit_date")
    list_filter = ("total_visits",)
    search_fields = ("name", "phone", "email")
    readonly_fields = ("created_at", "updated_at", "total_visits", "first_visit_date")
    fieldsets = (
        (None, {"fields": ("user", "name", "phone", "email")}),
        (
            "Visit details",
            {"fields": ("total_visits", "first_visit_date")},
        ),
        ("Notes", {"fields": ("notes",)}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )
