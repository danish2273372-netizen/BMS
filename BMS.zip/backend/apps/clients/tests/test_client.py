"""Tests for the Client model."""

import pytest

from apps.clients.models import Client
from apps.accounts.models import User

pytestmark = pytest.mark.django_db


def test_client_str():
    client = Client.objects.create(
        name="Alice Smith",
        phone="+15551234567",
    )
    assert str(client) == "Alice Smith"


def test_client_notes_blank_default():
    client = Client.objects.create(
        name="Bob",
        phone="+15551234568",
    )
    assert client.notes == ""


def test_client_user_nullable():
    """Client user FK should be nullable."""
    client = Client.objects.create(
        name="Walk-in",
        phone="+15551234569",
    )
    assert client.user is None


def test_client_total_visits_default_zero():
    client = Client.objects.create(
        name="New Client",
        phone="+15551234570",
    )
    assert client.total_visits == 0


def test_get_or_create_by_whatsapp_creates_new():
    client, created = Client.get_or_create_by_whatsapp("+15551234571")
    assert created is True
    assert client.phone == "+15551234571"
    assert client.name == "WhatsApp User (+15551234571)"


def test_get_or_create_by_whatsapp_with_name():
    client, created = Client.get_or_create_by_whatsapp("+15551234572", name="Carol White")
    assert created is True
    assert client.name == "Carol White"


def test_get_or_create_by_whatsapp_retrieves_existing():
    client = Client.objects.create(
        name="Dave",
        phone="+15551234573",
    )
    retrieved, created = Client.get_or_create_by_whatsapp("+15551234573")
    assert created is False
    assert retrieved.pk == client.pk
    assert retrieved.name == "Dave"


def test_get_or_create_by_whatsapp_case_insensitive():
    client = Client.objects.create(
        name="Eve",
        phone="+15551234574",
    )
    # Different case should match existing client
    retrieved, created = Client.get_or_create_by_whatsapp("+15551234574".upper())
    assert created is False


def test_unique_phone_enforced():
    Client.objects.create(name="First", phone="+15551234575")
    with pytest.raises(Exception):  # IntegrityError for unique constraint
        Client.objects.create(name="Second", phone="+15551234575")


def test_first_visit_date_nullable():
    client = Client.objects.create(
        name="No visit date",
        phone="+15551234576",
    )
    assert client.first_visit_date is None


def test_email_optional():
    client = Client.objects.create(
        name="No email",
        phone="+15551234577",
    )
    assert client.email == ""
