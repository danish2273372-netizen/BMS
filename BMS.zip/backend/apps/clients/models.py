"""Client and Barber domain models.

Each walk-in / repeat customer gets a ``Client`` record keyed by their
WhatsApp phone number.  Each barber gets a ``Barber`` record that links
back to their ``accounts.User``, tracks their Stripe Connect status,
and declares which services they offer.
"""

from django.contrib.auth import get_user_model
from django.core.validators import RegexValidator
from django.db import models
from django.utils.translation import gettext_lazy as _

User = get_user_model()

E164_REGEX = r"^\+[1-9]\d{7,14}$"

phone_validator = RegexValidator(
    regex=E164_REGEX,
    message=_("Phone number must be in E.164 format, e.g. +447700900123."),
)


# ── Client ──────────────────────────────────────────────────────────────


class Client(models.Model):
    """A customer of the barbershop.

    The ``phone`` number is the WhatsApp identifier and is unique across all
    clients.  A client may optionally be linked to a :class:`~accounts.User`
    (e.g. after they sign in via the mobile app).
    """

    user = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("user"),
        related_name="clients",
    )
    name = models.CharField(_("name"), max_length=120)
    phone = models.CharField(
        _("phone"),
        max_length=16,
        unique=True,
        validators=[phone_validator],
        help_text=_("E.164 WhatsApp number, e.g. +15551234567."),
    )
    email = models.CharField(_("email"), max_length=254, blank=True, default="")
    first_visit_date = models.DateField(_("first visit date"), null=True, blank=True)
    total_visits = models.PositiveIntegerField(_("total visits"), default=0)
    notes = models.TextField(_("notes"), blank=True, default="")
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)
    updated_at = models.DateTimeField(_("updated at"), auto_now=True)

    class Meta:
        verbose_name = _("client")
        verbose_name_plural = _("clients")
        ordering = ("-total_visits", "name")

    def __str__(self):
        return self.name

    @classmethod
    def get_or_create_by_whatsapp(cls, phone: str, name: str = None):
        """Return the existing client or create a new one from WhatsApp.

        Parameters
        ----------
        phone : str
            E.164 phone number.
        name : str, optional
            Display name to use when creating a new record.

        Returns
        -------
        tuple[Client, bool]
            ``(client, created)`` — ``created`` is True when a new row was
            inserted.
        """
        if name is None:
            name = f"WhatsApp User ({phone})"
        client, created = cls.objects.get_or_create(
            phone__iexact=phone,
            defaults={"name": name, "phone": phone},
        )
        return client, created
