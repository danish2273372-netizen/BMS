from django.apps import AppConfig


class AccountsConfig(AppConfig):
    """App config for the custom user / authentication app.

    The app lives under the ``apps.`` package but keeps the short label
    ``accounts`` so that ``AUTH_USER_MODEL = 'accounts.User'`` resolves.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.accounts"
    label = "accounts"
    verbose_name = "Accounts"
