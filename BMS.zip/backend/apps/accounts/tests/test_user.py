import pytest
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError

User = get_user_model()

pytestmark = pytest.mark.django_db


def test_auth_user_model_is_accounts_user(settings):
    assert settings.AUTH_USER_MODEL == "accounts.User"
    assert User.USERNAME_FIELD == "phone"


def test_create_user():
    user = User.objects.create_user(
        phone="+447700900123", full_name="Ada Barber", pin="1234"
    )
    assert user.pk is not None
    assert user.phone == "+447700900123"
    assert user.full_name == "Ada Barber"
    assert user.role == "barber"
    assert user.is_active is True
    assert user.is_staff is False
    assert user.is_superuser is False
    assert user.date_joined is not None
    # The PIN is hashed, never stored in the clear.
    assert user.password != "1234"


def test_create_user_requires_phone():
    with pytest.raises(ValueError):
        User.objects.create_user(phone="", full_name="No Phone", pin="1234")


def test_create_superuser():
    admin = User.objects.create_superuser(
        phone="+447700900999", full_name="Shop Owner", pin="654321"
    )
    assert admin.is_staff is True
    assert admin.is_superuser is True
    assert admin.is_active is True
    assert admin.role == "owner"


@pytest.mark.parametrize("bad_pin", ["123", "1", "1234567", "abcd", "12a4", ""])
def test_short_or_invalid_pin_raises_validation_error(bad_pin):
    user = User(phone="+447700900321", full_name="Bad Pin")
    with pytest.raises(ValidationError):
        user.set_pin(bad_pin)


def test_three_digit_pin_via_create_user_raises_validation_error():
    with pytest.raises(ValidationError):
        User.objects.create_user(
            phone="+447700900322", full_name="Three Digits", pin="123"
        )
    assert not User.objects.filter(phone="+447700900322").exists()


def test_check_pin():
    user = User.objects.create_user(
        phone="+447700900124", full_name="Check Pin", pin="4321"
    )
    assert user.check_pin("4321") is True
    assert user.check_pin("1234") is False
    # A malformed PIN is just wrong, it does not blow up the login path.
    assert user.check_pin("12") is False
    assert user.check_pin(None) is False


def test_check_pin_survives_reload_from_db():
    User.objects.create_user(phone="+447700900125", full_name="Reload", pin="987654")
    fetched = User.objects.get(phone="+447700900125")
    assert fetched.check_pin("987654") is True


def test_invalid_phone_rejected():
    with pytest.raises(ValidationError):
        User.objects.create_user(phone="07700900123", full_name="Local", pin="1234")
