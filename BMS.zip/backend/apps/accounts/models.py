"""Custom user model for the barbershop system.

Users log in with their phone number (E.164) plus a 4-6 digit numeric PIN.
The PIN is *not* stored in a bespoke column - it reuses Django's ``password``
field and hashing machinery, so hasher rotation and timing-safe comparison
keep working for free.
"""

import re

from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.core.exceptions import ValidationError
from django.core.validators import RegexValidator
from django.db import models
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

#: E.164: a leading ``+``, a non-zero country code digit, then 7-14 more digits.
E164_REGEX = r"^\+[1-9]\d{7,14}$"

phone_validator = RegexValidator(
    regex=E164_REGEX,
    message=_("Phone number must be in E.164 format, e.g. +447700900123."),
)

#: A PIN is 4 to 6 digits, nothing else.
PIN_REGEX = re.compile(r"^\d{4,6}$")


def validate_pin(raw_pin):
    """Validate a raw PIN and return it as a string.

    Raises:
        ValidationError: if the PIN is missing, non-numeric, or not 4-6 digits.
    """
    if raw_pin is None:
        raise ValidationError(_("A PIN is required."), code="pin_required")
    pin = str(raw_pin)
    if not PIN_REGEX.match(pin):
        raise ValidationError(
            _("PIN must be 4 to 6 digits (numbers only)."),
            code="invalid_pin",
        )
    return pin


class UserRole(models.TextChoices):
    OWNER = "owner", _("Owner")
    BARBER = "barber", _("Barber")
    STAFF = "staff", _("Staff")


class UserManager(BaseUserManager):
    """Manager for :class:`User`, keyed on phone instead of username."""

    use_in_migrations = True

    def _create_user(self, phone, password=None, pin=None, **extra_fields):
        if not phone:
            raise ValueError("A phone number is required.")
        phone = str(phone).strip()
        phone_validator(phone)

        user = self.model(phone=phone, **extra_fields)
        if pin is not None:
            user.set_pin(pin)
        elif password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_user(self, phone, password=None, pin=None, **extra_fields):
        extra_fields.setdefault("role", UserRole.BARBER)
        extra_fields.setdefault("is_staff", False)
        extra_fields.setdefault("is_superuser", False)
        extra_fields.setdefault("is_active", True)
        return self._create_user(phone, password=password, pin=pin, **extra_fields)

    def create_superuser(self, phone, password=None, pin=None, **extra_fields):
        extra_fields.setdefault("role", UserRole.OWNER)
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("is_active", True)

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self._create_user(phone, password=password, pin=pin, **extra_fields)


class User(AbstractBaseUser, PermissionsMixin):
    """A person who signs into the system: shop owner, barber, or staff."""

    phone = models.CharField(
        _("phone number"),
        max_length=16,
        unique=True,
        validators=[phone_validator],
        help_text=_("E.164 format, e.g. +447700900123."),
    )
    full_name = models.CharField(_("full name"), max_length=150, blank=True)
    role = models.CharField(
        _("role"),
        max_length=16,
        choices=UserRole.choices,
        default=UserRole.BARBER,
    )
    is_active = models.BooleanField(_("active"), default=True)
    is_staff = models.BooleanField(_("staff status"), default=False)
    date_joined = models.DateTimeField(_("date joined"), default=timezone.now)

    objects = UserManager()

    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = ["full_name"]

    class Meta:
        verbose_name = _("user")
        verbose_name_plural = _("users")
        ordering = ("full_name", "phone")

    def __str__(self):
        return f"{self.full_name or 'Unnamed'} ({self.phone})"

    def get_full_name(self):
        return self.full_name

    def get_short_name(self):
        return self.full_name.split(" ")[0] if self.full_name else self.phone

    # -- PIN helpers -------------------------------------------------------
    def set_pin(self, raw_pin):
        """Hash and store a 4-6 digit numeric PIN in the password field."""
        pin = validate_pin(raw_pin)
        self.set_password(pin)

    def check_pin(self, raw_pin):
        """Return True when ``raw_pin`` matches the stored PIN.

        A malformed PIN is simply wrong, never an exception - this is called
        on the login path and must not leak validation detail.
        """
        try:
            pin = validate_pin(raw_pin)
        except ValidationError:
            return False
        return self.check_password(pin)

    @property
    def is_owner(self):
        return self.role == UserRole.OWNER

    @property
    def is_barber(self):
        return self.role == UserRole.BARBER
