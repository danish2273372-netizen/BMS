"""Management command to create the Barbers group with limited permissions."""

from django.contrib.auth.models import Permission, Group
from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Create the Barbers group with limited permissions for barber-role staff."

    def handle(self, *args, **options):
        # Permissions that barbers CAN have (view-only on certain models)
        barber_perms = [
            ("appointments", "view_appointment"),
            ("appointments", "view_appointmentservice"),
            ("payments", "view_payment"),
            ("core", "view_shop"),
            ("core", "view_shophours"),
            ("catalog", "view_service"),
            ("barbers", "view_barber"),
        ]

        group, created = Group.objects.get_or_create(name="Barbers")
        self.stdout.write(f"{'Created' if created else 'Updated'} group: Barbers")

        perms_added = 0
        for app_label, codename in barber_perms:
            try:
                perm = Permission.objects.get(
                    content_type__app_label=app_label,
                    codename=codename,
                )
                if perm not in group.permissions.all():
                    group.permissions.add(perm)
                    perms_added += 1
            except Permission.DoesNotExist:
                self.stdout.write(
                    self.style.WARNING(
                        f"Permission {app_label}.{codename} not found"
                    )
                )

        self.stdout.write(
            self.style.SUCCESS(
                f"Added {perms_added} permission(s) to Barbers group."
            )
        )
