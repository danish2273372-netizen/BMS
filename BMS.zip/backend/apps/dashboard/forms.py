"""Forms for dashboard admin views."""

from datetime import date

from django import forms

from apps.barbers.models import Barber


class RevenueByChairForm(forms.Form):
    """Filter form for the revenue-by-chair report."""

    barber = forms.ModelChoiceField(
        queryset=Barber.objects.none(),
        required=False,
        label="Barber",
        widget=forms.Select(attrs={"class": "form-select"}),
    )
    start_date = forms.DateField(
        required=False,
        label="Start date",
        widget=forms.DateInput(attrs={"type": "date", "class": "form-control"}),
    )
    end_date = forms.DateField(
        required=False,
        label="End date",
        widget=forms.DateInput(attrs={"type": "date", "class": "form-control"}),
    )

    def __init__(self, *args, shop_id=None, **kwargs):
        super().__init__(*args, **kwargs)
        if shop_id:
            self.fields["barber"].queryset = Barber.objects.filter(shop_id=shop_id)
