"""URL configuration for the dashboard app."""

from django.urls import path

from . import views

urlpatterns = [
    path("dashboard/", views.dashboard_index, name="dashboard_index"),
    path("reports/revenue-by-chair/", views.revenue_by_chair, name="revenue_by_chair"),
]
