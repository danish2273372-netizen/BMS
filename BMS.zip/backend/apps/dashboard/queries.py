"""Plain query functions for the dashboard admin views.

These functions are intentionally free of HTTP/Django view machinery so they
can be tested in isolation and reused across admin views, management commands,
and reporting endpoints.
"""

from datetime import date, datetime
from decimal import Decimal

from django.db.models import Sum, Count, Q
from django.utils import timezone


def revenue_between(
    start: date | datetime,
    end: date | datetime,
    barber=None,
) -> dict:
    """Return aggregated revenue across all barbers (or a single barber).

    Parameters
    ----------
    start / end : date or datetime
        Inclusive bounds.  ``paid_at`` must fall within [start, end].
    barber : barbers.Barber or None
        When supplied, limits aggregation to that barber's payments.

    Returns
    -------
    dict
        Keys: ``total``, ``cash``, ``card``, ``in_person_card``,
        ``payment_count``, ``barbers_count``.
    """
    from apps.payments.models import Payment, PaymentMethod, PaymentStatus

    qs = Payment.objects.filter(status=PaymentStatus.PAID)

    # Convert to timezone-aware datetimes
    start = timezone.make_aware(start) if not isinstance(start, datetime) else start
    end = timezone.make_aware(end) if not isinstance(end, datetime) else end

    qs = qs.filter(paid_at__gte=start, paid_at__lte=end)

    if barber is not None:
        qs = qs.filter(barber=barber)

    total = qs.aggregate(
        total=Sum("amount", default=Decimal("0")),
        cash=Sum(
            "amount",
            filter=Q(payment_method=PaymentMethod.CASH),
            default=Decimal("0"),
        ),
        card=Sum(
            "amount",
            filter=Q(payment_method=PaymentMethod.CARD_LINK),
            default=Decimal("0"),
        ),
        in_person_card=Sum(
            "amount",
            filter=Q(payment_method=PaymentMethod.IN_PERSON_CARD),
            default=Decimal("0"),
        ),
        payment_count=Count("id"),
    )

    # Count distinct barbers with paid payments in this range
    barbers_count = qs.values_list("barber_id", flat=True).distinct().count()

    total["barbers_count"] = barbers_count
    total["total"] = total["total"]
    total["cash"] = total["cash"]
    total["card"] = total["card"]
    total["in_person_card"] = total["in_person_card"]
    total["payment_count"] = total["payment_count"]

    return total


def todays_appointments():
    """Return a list of dicts with today's appointments.

    Each dict contains:
        - reference_number, client_name, barber_name, requested_time,
          status, final_price
    """
    today_start = timezone.make_aware(datetime.combine(date.today(), datetime.min.time()))
    today_end = timezone.make_aware(datetime.combine(date.today(), datetime.max.time()))

    from apps.appointments.models import Appointment

    qs = (
        Appointment.objects.filter(
            requested_time__gte=today_start,
            requested_time__lte=today_end,
        )
        .select_related("client", "barber", "barber__user")
        .order_by("requested_time")
    )

    results = []
    for apt in qs:
        results.append(
            {
                "reference_number": apt.reference_number,
                "client_name": apt.client.name if apt.client else "Unknown",
                "barber_name": apt.barber.display_name,
                "requested_time": apt.requested_time,
                "status": apt.status,
                "final_price": apt.final_price,
            }
        )

    return results


def unpaid_rent(cycle_start: date | None = None, cycle_end: date | None = None):
    """Return count of barbers with unpaid rent for the given period.

    Parameters
    ----------
    cycle_start / cycle_end : date, optional
        If provided, filters rent payments to the given period.
        Defaults to the current month.

    Returns
    -------
    int
        Number of distinct barbers with at least one unpaid rent payment
        in the cycle.
    """
    from apps.finance.models import RentPayment

    qs = RentPayment.objects.filter(paid=False)

    if cycle_start is not None:
        qs = qs.filter(period_start__gte=cycle_start)
    if cycle_end is not None:
        qs = qs.filter(period_end__lte=cycle_end)

    return qs.values_list("barber_id", flat=True).distinct().count()
