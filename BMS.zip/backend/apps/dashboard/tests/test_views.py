"""Client (HTTP) tests for dashboard admin views."""

from datetime import datetime, timedelta

from decimal import Decimal

import pytest
from django.contrib.auth import get_user_model
from django.test import Client as DjangoClient
from django.urls import reverse
from apps.barbers.models import Barber, RentType
from apps.clients.models import Client
from apps.catalog.models import Service
from apps.payments.models import Payment, PaymentMethod, PaymentStatus
from apps.appointments.models import Appointment, AppointmentService
from django.utils import timezone

User = get_user_model()


@pytest.fixture
def admin_user(db):
    """Create a staff superuser."""
    return User.objects.create_superuser(
        phone="+11111111111",
        password="adminpin",
        full_name="Admin User",
        role="owner",
    )


@pytest.fixture
def staff_user(db):
    """Create a non-superuser staff member."""
    return User.objects.create_user(
        phone="+22222222222",
        password="staffpin",
        full_name="Staff User",
        role="staff",
        is_staff=True,
    )


class TestDashboardIndexView:
    """Test /admin/dashboard/ endpoint."""

    def test_redirects_anonymous(self, client):
        """Anonymous users are redirected to login."""
        resp = client.get(reverse("admin:dashboard_index"))
        assert resp.status_code == 302
        assert "login" in resp["Location"] or "redirect" in resp["Location"].lower()

    def test_returns_200_for_superuser(self, admin_user, client):
        """A logged-in superuser sees the dashboard (200 OK)."""
        client.login(username="+11111111111", password="adminpin")
        resp = client.get(reverse("admin:dashboard_index"))
        assert resp.status_code == 200

    def test_returns_200_for_staff(self, staff_user, client):
        """A logged-in staff member sees the dashboard."""
        client.login(username="+22222222222", password="staffpin")
        resp = client.get(reverse("admin:dashboard_index"))
        assert resp.status_code == 200


class TestRevenueByChairView:
    """Test /admin/reports/revenue-by-chair/ endpoint."""

    def test_redirects_anonymous(self, client):
        """Anonymous users are redirected to login."""
        resp = client.get(reverse("admin:dashboard_revenue_by_chair"))
        assert resp.status_code == 302

    def test_returns_200_for_superuser(self, admin_user, client):
        """A logged-in superuser sees the revenue report."""
        client.login(username="+11111111111", password="adminpin")
        resp = client.get(
            reverse("admin:dashboard_revenue_by_chair"),
            {"start_date": "2025-06-01", "end_date": "2025-06-30"},
        )
        assert resp.status_code == 200
