"""Tests for role-based admin permissions.

Verifies:
- A barber-role staff user sees only their own appointments in the
  admin changelist queryset.
- A barber-role staff user receives 403 on the expenses changelist
  (and cannot change/delete expense rows belonging to others).
- An owner (superuser) sees everything.
"""

import pytest
from django.contrib.auth import get_user_model
from django.contrib.contenttypes.models import ContentType
from django.contrib.auth.models import Group
from django.test import RequestFactory

from apps.appointments.admin import AppointmentAdmin
from apps.appointments.models import Appointment, AppointmentService, Status
from apps.barbers.models import Barber
from apps.catalog.models import Service
from apps.clients.models import Client
from apps.core.models import Shop
from apps.dashboard.admin import dashboard_site
from apps.finance.admin import ExpenseAdmin, RentPaymentAdmin
from apps.finance.models import Expense, ExpenseCategory, RentPayment
from apps.payments.admin import PaymentAdmin
from apps.payments.models import Payment, PaymentStatus

User = get_user_model()

pytestmark = pytest.mark.django_db


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture()
def shop():
    return Shop.objects.create(
        name="Test Shop",
        address_line1="123 Main St",
        city="Springfield",
        state="IL",
        postal_code="62704",
    )


@pytest.fixture()
def service_a(shop):
    svc = Service.objects.create(
        name="Haircut",
        price=25.00,
        duration_minutes=30,
    )
    return svc


@pytest.fixture()
def service_b():
    return Service.objects.create(
        name="Beard trim",
        price=15.00,
        duration_minutes=20,
    )


@pytest.fixture()
def barber1(shop):
    user = User.objects.create_user(
        phone="+15551234567",
        full_name="Ada Barber",
        pin="1234",
        is_staff=True,
    )
    barber = Barber.objects.create(
        user=user,
        shop=shop,
        display_name="Ada",
        chair_number=1,
    )
    return barber


@pytest.fixture()
def barber2(shop):
    user = User.objects.create_user(
        phone="+15551234568",
        full_name="Bob Barber",
        pin="1234",
        is_staff=True,
    )
    barber = Barber.objects.create(
        user=user,
        shop=shop,
        display_name="Bob",
        chair_number=2,
    )
    return barber


@pytest.fixture()
def owner_user():
    return User.objects.create_superuser(
        phone="+15550000000",
        full_name="Shop Owner",
        pin="9999",
    )


@pytest.fixture()
def barber_user(barber1):
    """Returns the User linked to barber1."""
    return barber1.user


@pytest.fixture()
def client():
    return Client.objects.create(
        name="John Customer",
        phone="+15559876543",
    )


# ── Helpers ─────────────────────────────────────────────────────────────


def _make_appointment(client, barber, services=None, **kwargs):
    from django.utils import timezone
    import random, string
    requested_time = kwargs.pop(
        "requested_time",
        timezone.now().replace(hour=14, minute=0, second=0, microsecond=0),
    )
    status = kwargs.pop("status", Status.BOOKED)
    ref = kwargs.pop("reference_number", None)
    if ref is None:
        ref = "".join(random.choices(string.ascii_uppercase + string.digits, k=6))

    apt = Appointment.objects.create(
        client=client,
        barber=barber,
        requested_time=requested_time,
        status=status,
        reference_number=ref,
        **kwargs,
    )
    services = services or list(Service.objects.filter(active=True)[:1])
    for svc in services:
        AppointmentService.objects.create(
            appointment=apt,
            service=svc,
            price_at_booking=svc.price,
            duration_minutes=svc.duration_minutes,
        )
    return apt


def _make_request(user):
    """Build a minimal Django request with ``user`` attached."""
    factory = RequestFactory()
    req = factory.get("/admin/")
    req.user = user
    return req


# ── Tests: AppointmentAdmin ─────────────────────────────────────────────


class TestAppointmentAdminQueryset:
    """Barber sees only own appointments; owner sees all."""

    def test_owner_sees_all_appointments(self, shop, client, barber1, barber2, service_a, owner_user):
        """Owner user sees appointments for all barbers."""
        apt1 = _make_appointment(client, barber1, services=[service_a])
        apt2 = _make_appointment(client, barber2, services=[service_a])

        admin = AppointmentAdmin(Appointment, dashboard_site)
        req = _make_request(owner_user)

        qs = admin.get_queryset(req)
        assert qs.count() == 2
        assert apt1 in qs
        assert apt2 in qs

    def test_barber_sees_only_own_appointments(self, shop, client, barber1, barber2, service_a, barber_user):
        """Barber sees only appointments assigned to their Barber record."""
        apt1 = _make_appointment(client, barber1, services=[service_a])
        apt2 = _make_appointment(client, barber2, services=[service_a])

        admin = AppointmentAdmin(Appointment, dashboard_site)
        req = _make_request(barber_user)

        qs = admin.get_queryset(req)
        assert qs.count() == 1
        assert apt1 in qs
        assert apt2 not in qs

    def test_barber_has_change_permission_for_own(self, shop, client, barber1, service_a, barber_user):
        admin = AppointmentAdmin(Appointment, dashboard_site)
        apt = _make_appointment(client, barber1, services=[service_a])
        req = _make_request(barber_user)

        assert admin.has_change_permission(req, obj=apt) is True

    def test_barber_denied_change_permission_for_other(self, shop, client, barber1, barber2, service_a, barber_user):
        admin = AppointmentAdmin(Appointment, dashboard_site)
        apt = _make_appointment(client, barber2, services=[service_a])
        req = _make_request(barber_user)

        assert admin.has_change_permission(req, obj=apt) is False

    def test_barber_can_list(self, barber1, barber_user):
        """Barber can at least list the changelist (get_queryset returns rows)."""
        admin = AppointmentAdmin(Appointment, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_change_permission(req) is True

    def test_barber_cannot_add_appointment(self, barber1, barber_user):
        admin = AppointmentAdmin(Appointment, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_add_permission(req) is False

    def test_barber_can_delete_own(self, shop, client, barber1, service_a, barber_user):
        admin = AppointmentAdmin(Appointment, dashboard_site)
        apt = _make_appointment(client, barber1, services=[service_a])
        req = _make_request(barber_user)
        assert admin.has_delete_permission(req, obj=apt) is True

    def test_owner_sees_everything(self, shop, client, barber1, barber2, service_a, owner_user):
        admin = AppointmentAdmin(Appointment, dashboard_site)
        req = _make_request(owner_user)
        assert admin.has_add_permission(req) is True
        assert admin.has_change_permission(req) is True
        assert admin.has_delete_permission(req) is True


# ── Tests: PaymentAdmin ─────────────────────────────────────────────────


class TestPaymentAdminPermissions:
    """Barber sees only own payments; owner sees all."""

    def test_barber_sees_only_own_payments(self, shop, client, barber1, barber2, service_a, barber_user):
        apt1 = _make_appointment(client, barber1, services=[service_a])
        Payment.objects.create(
            appointment=apt1,
            barber=barber1,
            amount=25.00,
            status=PaymentStatus.PAID,
        )
        apt2 = _make_appointment(client, barber2, services=[service_a])
        Payment.objects.create(
            appointment=apt2,
            barber=barber2,
            amount=25.00,
            status=PaymentStatus.PAID,
        )

        admin = PaymentAdmin(Payment, dashboard_site)
        req = _make_request(barber_user)
        qs = admin.get_queryset(req)
        assert qs.count() == 1

    def test_barber_cannot_add_payment(self, barber1, barber_user):
        admin = PaymentAdmin(Payment, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_add_permission(req) is False

    def test_owner_can_add_payment(self, owner_user):
        admin = PaymentAdmin(Payment, dashboard_site)
        req = _make_request(owner_user)
        assert admin.has_add_permission(req) is True


# ── Tests: ExpenseAdmin ─────────────────────────────────────────────────


class TestExpenseAdminPermissions:
    """Barber cannot create expenses and sees only own barber's expenses."""

    def test_barber_cannot_create_expenses(self, barber1, barber_user):
        admin = ExpenseAdmin(Expense, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_add_permission(req) is False

    def test_barber_sees_only_own_barber_expenses(self, shop, barber1, barber2, barber_user):
        exp1 = Expense.objects.create(
            category=ExpenseCategory.OTHER,
            amount=10.00,
            date="2025-01-01",
            barber=barber1,
        )
        exp2 = Expense.objects.create(
            category=ExpenseCategory.OTHER,
            amount=20.00,
            date="2025-01-01",
            barber=barber2,
        )

        admin = ExpenseAdmin(Expense, dashboard_site)
        req = _make_request(barber_user)
        qs = admin.get_queryset(req)
        assert qs.count() == 1
        assert exp1 in qs
        assert exp2 not in qs

    def test_barber_gets_403_on_expense_changelist(self, barber1, barber_user):
        """Barber-role staff user cannot access the expense changelist at all."""
        # The has_change_permission returning False when obj is None means
        # the admin will not show the changelist.
        admin = ExpenseAdmin(Expense, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_change_permission(req) is False

    def test_owner_can_manage_expenses(self, owner_user):
        admin = ExpenseAdmin(Expense, dashboard_site)
        req = _make_request(owner_user)
        assert admin.has_add_permission(req) is True
        assert admin.has_change_permission(req) is True


# ── Tests: RentPaymentAdmin ─────────────────────────────────────────────


class TestRentPaymentAdminPermissions:
    """Barber cannot create rent payments."""

    def test_barber_cannot_add_rent_payment(self, barber1, barber_user):
        admin = RentPaymentAdmin(RentPayment, dashboard_site)
        req = _make_request(barber_user)
        assert admin.has_add_permission(req) is False

    def test_barber_sees_only_own_barber_rent_payments(self, shop, barber1, barber2, barber_user):
        from datetime import date
        rp1 = RentPayment.objects.create(
            barber=barber1,
            amount=500.00,
            period_start=date(2025, 1, 1),
            period_end=date(2025, 1, 31),
            period_label="January 2025",
        )
        rp2 = RentPayment.objects.create(
            barber=barber2,
            amount=600.00,
            period_start=date(2025, 1, 1),
            period_end=date(2025, 1, 31),
            period_label="January 2025",
        )

        admin = RentPaymentAdmin(RentPayment, dashboard_site)
        req = _make_request(barber_user)
        qs = admin.get_queryset(req)
        assert qs.count() == 1
        assert rp1 in qs
        assert rp2 not in qs

    def test_owner_can_manage_rent_payments(self, owner_user):
        admin = RentPaymentAdmin(RentPayment, dashboard_site)
        req = _make_request(owner_user)
        assert admin.has_add_permission(req) is True


# ── Tests: Bootstrap roles command ──────────────────────────────────────


class TestBootstrapRolesCommand:
    """Verify the management command creates the Barbers group."""

    def test_creates_barbers_group(self, settings):
        from django.core.management import call_command
        from io import StringIO

        out = StringIO()
        call_command("bootstrap_roles", stdout=out)
        group = Group.objects.get(name="Barbers")
        assert group.pk is not None

        # Check that view permissions are assigned
        view_codenames = {
            "view_appointment",
            "view_appointmentservice",
            "view_payment",
            "view_shop",
            "view_shophours",
            "view_service",
            "view_barber",
        }
        assigned = set(group.permissions.values_list("codename", flat=True))
        for codename in view_codenames:
            assert codename in assigned, f"Missing permission: {codename}"
