"""Tests for dashboard query functions."""

from datetime import date, datetime as dt_datetime, timedelta
from decimal import Decimal

import pytest
from django.utils import timezone

from apps.dashboard.queries import (
    revenue_between,
    todays_appointments,
    unpaid_rent,
)
from apps.payments.models import Payment, PaymentMethod, PaymentStatus


@pytest.mark.django_db
class TestRevenueBetween:
    """Test revenue_between aggregation with seeded payments."""

    def test_returns_zero_for_empty_range(self):
        now = timezone.make_aware(dt_datetime(2025, 6, 15, 12, 0, 0))
        result = revenue_between(now, now + timedelta(days=1))
        assert result["total"] == 0
        assert result["cash"] == 0
        assert result["card"] == 0
        assert result["in_person_card"] == 0
        assert result["payment_count"] == 0
        assert result["barbers_count"] == 0

    def test_includes_paid_payments(self):
        barber = barber_factory()
        client = client_factory()
        now = timezone.make_aware(dt_datetime(2025, 6, 15, 12, 0, 0))
        apt1 = appointment_factory(barber=barber, client=client, requested_time=now)
        apt2 = appointment_factory(barber=barber, client=client, requested_time=now + timedelta(hours=1))

        Payment.objects.create(
            appointment=apt1,
            barber=barber,
            amount=Decimal("50.00"),
            payment_method=PaymentMethod.CASH,
            status=PaymentStatus.PAID,
            paid_at=now,
        )
        Payment.objects.create(
            appointment=apt2,
            barber=barber,
            amount=Decimal("30.00"),
            payment_method=PaymentMethod.CARD_LINK,
            status=PaymentStatus.PAID,
            paid_at=now,
        )

        result = revenue_between(now, now + timedelta(days=1))
        assert result["total"] == Decimal("80.00")
        assert result["cash"] == Decimal("50.00")
        assert result["card"] == Decimal("30.00")
        assert result["payment_count"] == 2
        assert result["barbers_count"] == 1

    def test_excludes_non_paid_payments(self):
        barber = barber_factory()
        client = client_factory()
        now = timezone.make_aware(dt_datetime(2025, 6, 15, 12, 0, 0))

        # Paid payment
        apt_paid = appointment_factory(barber=barber, client=client, requested_time=now)
        Payment.objects.create(
            appointment=apt_paid,
            barber=barber,
            amount=Decimal("100.00"),
            payment_method=PaymentMethod.CASH,
            status=PaymentStatus.PAID,
            paid_at=now,
        )
        # Pending — not counted
        apt_pending = appointment_factory(barber=barber, client=client, requested_time=now + timedelta(hours=1))
        Payment.objects.create(
            appointment=apt_pending,
            barber=barber,
            amount=Decimal("200.00"),
            payment_method=PaymentMethod.CARD_LINK,
            status=PaymentStatus.PENDING,
            paid_at=now,
        )
        # Failed — not counted
        apt_failed = appointment_factory(barber=barber, client=client, requested_time=now + timedelta(hours=2))
        Payment.objects.create(
            appointment=apt_failed,
            barber=barber,
            amount=Decimal("150.00"),
            payment_method=PaymentMethod.CARD_LINK,
            status=PaymentStatus.FAILED,
            paid_at=now,
        )
        # Refunded — not counted
        apt_refunded = appointment_factory(barber=barber, client=client, requested_time=now + timedelta(hours=3))
        Payment.objects.create(
            appointment=apt_refunded,
            barber=barber,
            amount=Decimal("50.00"),
            payment_method=PaymentMethod.IN_PERSON_CARD,
            status=PaymentStatus.REFUNDED,
            paid_at=now,
        )

        result = revenue_between(now, now + timedelta(days=1))
        assert result["total"] == Decimal("100.00")
        assert result["cash"] == Decimal("100.00")
        assert result["card"] == 0
        assert result["in_person_card"] == 0
        assert result["payment_count"] == 1

    def test_filters_by_barber(self):
        barber1 = barber_factory()
        barber2 = barber_factory()
        client = client_factory()
        now = timezone.make_aware(dt_datetime(2025, 6, 15, 12, 0, 0))
        apt1 = appointment_factory(barber=barber1, client=client, requested_time=now)
        apt2 = appointment_factory(barber=barber2, client=client, requested_time=now)

        Payment.objects.create(
            appointment=apt1,
            barber=barber1,
            amount=Decimal("100.00"),
            payment_method=PaymentMethod.CASH,
            status=PaymentStatus.PAID,
            paid_at=now,
        )
        Payment.objects.create(
            appointment=apt2,
            barber=barber2,
            amount=Decimal("200.00"),
            payment_method=PaymentMethod.CARD_LINK,
            status=PaymentStatus.PAID,
            paid_at=now,
        )

        result = revenue_between(now, now + timedelta(days=1), barber=barber1)
        assert result["total"] == Decimal("100.00")
        assert result["barbers_count"] == 1

        result2 = revenue_between(now, now + timedelta(days=1), barber=barber2)
        assert result2["total"] == Decimal("200.00")
        assert result2["barbers_count"] == 1

    def test_excludes_outside_date_range(self):
        barber = barber_factory()
        client = client_factory()
        in_range = timezone.make_aware(dt_datetime(2025, 6, 15, 12, 0, 0))
        out_range = timezone.make_aware(dt_datetime(2025, 6, 10, 12, 0, 0))
        apt1 = appointment_factory(barber=barber, client=client, requested_time=in_range)
        apt2 = appointment_factory(barber=barber, client=client, requested_time=out_range)

        Payment.objects.create(
            appointment=apt1,
            barber=barber,
            amount=Decimal("100.00"),
            payment_method=PaymentMethod.CASH,
            status=PaymentStatus.PAID,
            paid_at=in_range,
        )
        Payment.objects.create(
            appointment=apt2,
            barber=barber,
            amount=Decimal("50.00"),
            payment_method=PaymentMethod.CARD_LINK,
            status=PaymentStatus.PAID,
            paid_at=out_range,
        )

        result = revenue_between(in_range - timedelta(days=1), in_range + timedelta(days=1))
        assert result["total"] == Decimal("100.00")
        assert result["payment_count"] == 1


@pytest.mark.django_db
class TestTodaysAppointments:
    """Test todays_appointments query."""

    def test_returns_empty_when_no_appointments(self):
        # If no appointments exist for today, should return empty list
        from apps.clients.models import Client
        from apps.barbers.models import Barber

        # Make sure there are no appointments today
        result = todays_appointments()
        assert result == []

    def test_returns_today_appointments(self):
        barber = barber_factory()
        client = client_factory()
        today = timezone.make_aware(dt_datetime.combine(date.today(), dt_datetime(2025, 1, 1, 8, 0).time()))
        apt = appointment_factory(barber=barber, client=client, requested_time=today)

        result = todays_appointments()
        assert len(result) == 1
        assert result[0]["reference_number"] == apt.reference_number
        assert result[0]["client_name"] == client.name
        assert result[0]["barber_name"] == barber.display_name
        assert result[0]["final_price"] is None  # Not calculated


@pytest.mark.django_db
class TestUnpaidRent:
    """Test unpaid_rent query."""

    def test_returns_zero_when_all_paid(self):
        barber = barber_factory()
        rent_payment_factory(barber=barber, paid=True)

        assert unpaid_rent() == 0

    def test_counts_unpaid_barbers(self):
        barber1 = barber_factory()
        barber2 = barber_factory()
        barber3 = barber_factory()

        rent_payment_factory(barber=barber1, paid=False)
        rent_payment_factory(barber=barber2, paid=False)
        rent_payment_factory(barber=barber3, paid=True)

        assert unpaid_rent() == 2

    def test_filters_by_period(self):
        barber1 = barber_factory()
        barber2 = barber_factory()

        rent_payment_factory(
            barber=barber1,
            paid=False,
            period_start=date(2025, 5, 1),
            period_end=date(2025, 5, 31),
        )
        rent_payment_factory(
            barber=barber2,
            paid=False,
            period_start=date(2025, 6, 1),
            period_end=date(2025, 6, 30),
        )

        assert unpaid_rent(
            cycle_start=date(2025, 6, 1),
            cycle_end=date(2025, 6, 30),
        ) == 1


# ---------------------------------------------------------------------------
# Inline factories (no external dependency)
# ---------------------------------------------------------------------------

from django.contrib.auth import get_user_model
from apps.barbers.models import Barber, RentType
from apps.clients.models import Client
from apps.catalog.models import Service
from apps.appointments.models import Appointment, AppointmentService, Status
from apps.finance.models import RentPayment
from apps.core.models import Shop

User = get_user_model()

_counter = [0]


def _get_shop():
    if not Shop.objects.exists():
        Shop.objects.create(
            name="Test Shop",
            address_line1="1 Main St",
            city="New York",
            state="NY",
            postal_code="10001",
        )
    return Shop.objects.first()


def barber_factory(**kwargs):
    """Create a Barber with a linked user."""
    _counter[0] += 1
    user = User.objects.create_user(
        phone="+1" + "".join([str((_counter[0] + i) % 10) for i in range(10)]),
        pin="1234",
        full_name="Barber " + str(_counter[0]),
        role="barber",
    )
    shop = _get_shop()
    defaults = {
        "display_name": "Test Barber " + str(_counter[0]),
        "rent_type": RentType.FLAT_FEE,
        "rent_amount": Decimal("200.00"),
        "rent_cycle": "weekly",
        "shop": shop,
        "chair_number": _counter[0],
        **kwargs,
    }
    defaults["user"] = user
    return Barber.objects.create(**defaults)


def client_factory(**kwargs):
    """Create a Client."""
    _counter[0] += 1
    return Client.objects.create(
        name=kwargs.pop("name", "Test Client " + str(_counter[0])),
        phone="+1" + "".join([str((_counter[0] + i) % 10) for i in range(10)]),
        **kwargs,
    )


def service_factory(**kwargs):
    """Create a Service."""
    _counter[0] += 1
    return Service.objects.create(
        name=kwargs.pop("name", "Test Service " + str(_counter[0])),
        price=kwargs.pop("price", Decimal("25.00")),
        duration_minutes=kwargs.pop("duration_minutes", 30),
        **kwargs,
    )


def appointment_factory(**kwargs):
    """Create an Appointment with required client, barber, and services."""
    barber = kwargs.setdefault("barber", barber_factory())
    client = kwargs.setdefault("client", client_factory())
    kwargs["status"] = Status.BOOKED
    kwargs["created_via"] = "web"

    apt = Appointment.objects.create(**kwargs)

    # Ensure at least one appointment service (required by clean)
    if not AppointmentService.objects.filter(appointment=apt).exists():
        svc = service_factory()
        AppointmentService.objects.create(
            appointment=apt,
            service=svc,
            price_at_booking=svc.price,
            duration_minutes=svc.duration_minutes,
        )

    return apt


def rent_payment_factory(**kwargs):
    """Create a RentPayment."""
    barber = kwargs.setdefault("barber", barber_factory())
    defaults = {
        "amount": Decimal("500.00"),
        "period_start": date(2025, 6, 1),
        "period_end": date(2025, 6, 30),
        **kwargs,
    }
    return RentPayment.objects.create(**defaults)
