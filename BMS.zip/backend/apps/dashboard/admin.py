"""Custom AdminSite and dashboard admin views."""

from datetime import date, datetime, timedelta

from django.contrib import admin
from django.shortcuts import render
from django.urls import path
from django.utils import timezone

from apps.barbers.models import Barber
from apps.dashboard.forms import RevenueByChairForm
from apps.dashboard.queries import (
    revenue_between,
    todays_appointments,
    unpaid_rent,
)
from apps.payments.models import Payment, PaymentMethod, PaymentStatus


class DashboardAdminSite(admin.AdminSite):
    """Custom admin site with a dashboard index template and extra admin views."""

    name = "dashboard_admin"

    def get_urls(self):
        """Return dashboard URLs prepended to the default admin URLs."""
        from django.contrib import admin as default_admin

        default_urls = default_admin.site.urls
        default_patterns = list(default_urls[0])

        dashboard_urls = [
            path(
                "dashboard/",
                self.admin_view(self.dashboard_index),
                name="dashboard_index",
            ),
            path(
                "reports/revenue-by-chair/",
                self.admin_view(self.revenue_by_chair_view),
                name="dashboard_revenue_by_chair",
            ),
        ]

        return dashboard_urls + default_patterns

    def dashboard_index(self, request):
        """Admin dashboard home — today's appointments, revenue summary, unpaid rent count."""
        context = {}

        appointments = todays_appointments()
        context["appointments"] = appointments
        context["today_count"] = len(appointments)

        today_start = timezone.make_aware(datetime.combine(date.today(), datetime.min.time()))
        today_end = timezone.make_aware(datetime.combine(date.today(), datetime.max.time()))

        week_start = today_start - timedelta(days=today_start.weekday())
        month_start = timezone.make_aware(datetime.combine(date.today().replace(day=1), datetime.min.time()))

        context["revenue_today"] = revenue_between(today_start, today_end)
        context["revenue_week"] = revenue_between(week_start, today_end)
        context["revenue_month"] = revenue_between(month_start, today_end)
        context["unpaid_rent_count"] = unpaid_rent()

        return render(request, "admin/dashboard/index.html", context)

    def revenue_by_chair_view(self, request):
        """Admin report — gross revenue per barber, filterable by barber and date range."""
        shop_id = None
        try:
            shop_id = request.user.barber.shop_id
        except (AttributeError, Barber.DoesNotExist):
            pass

        form = RevenueByChairForm(request.GET, shop_id=shop_id)
        if form.is_valid():
            barber = form.cleaned_data.get("barber")
            start_date = form.cleaned_data.get("start_date")
            end_date = form.cleaned_data.get("end_date")

            if start_date and end_date:
                start = timezone.make_aware(datetime.combine(start_date, datetime.min.time()))
                end = timezone.make_aware(datetime.combine(end_date, datetime.max.time()))
                revenues = revenue_between(start, end, barber=barber)

                # Per-barber breakdown
                qs = Payment.objects.filter(
                    status=PaymentStatus.PAID,
                    paid_at__gte=start,
                    paid_at__lte=end,
                )
                if barber:
                    qs = qs.filter(barber=barber)

                barber_data = {}
                for p in qs.select_related("barber"):
                    barber_id = p.barber_id or "Unknown"
                    if barber_id not in barber_data:
                        barber_data[barber_id] = {
                            "total": 0.0,
                            "cash": 0.0,
                            "card": 0.0,
                            "in_person_card": 0.0,
                            "count": 0,
                            "barber_name": (
                                p.barber.display_name
                                if p.barber
                                else "Unknown"
                            ),
                        }
                    bd = barber_data[barber_id]
                    amt = float(p.amount)
                    bd["total"] += amt
                    if p.payment_method == PaymentMethod.CASH:
                        bd["cash"] += amt
                    elif p.payment_method == PaymentMethod.CARD_LINK:
                        bd["card"] += amt
                    elif p.payment_method == PaymentMethod.IN_PERSON_CARD:
                        bd["in_person_card"] += amt
                    bd["count"] += 1

                barber_list = sorted(
                    barber_data.items(),
                    key=lambda x: x[1]["total"],
                    reverse=True,
                )

                context = {
                    "barber_list": barber_list,
                    "total_revenue": revenues["total"],
                    "cash": revenues["cash"],
                    "card": revenues["card"],
                    "in_person_card": revenues["in_person_card"],
                    "start_date": start_date,
                    "end_date": end_date,
                    "form": form,
                }
            else:
                context = {
                    "error": "Please select both start and end dates.",
                    "form": form,
                }
        else:
            context = {"error": "Form invalid.", "form": form}

        return render(
            request, "admin/dashboard/revenue_by_chair.html", context
        )


# Create the custom admin site instance (replaces the default site)
dashboard_site = DashboardAdminSite(name="dashboard_admin")
