"""Admin registration for shop configuration."""

from django.contrib import admin

from .models import Shop, ShopHours


class ShopHoursInline(admin.TabularInline):
    """Edit the seven weekday rows inline on the shop page."""

    model = ShopHours
    extra = 0
    fields = ("weekday", "open_time", "close_time", "is_closed")
    ordering = ("weekday",)


@admin.register(Shop)
class ShopAdmin(admin.ModelAdmin):
    """Admin for the barbershop record."""

    list_display = (
        "name",
        "city",
        "state",
        "phone",
        "whatsapp_number",
        "charges_sales_tax",
        "sales_tax_rate",
    )
    list_filter = ("state", "charges_sales_tax", "timezone")
    search_fields = ("name", "city", "postal_code", "phone", "whatsapp_number")
    readonly_fields = ("created_at", "updated_at")
    inlines = (ShopHoursInline,)
    fieldsets = (
        (None, {"fields": ("name", "timezone")}),
        (
            "Address",
            {"fields": ("address_line1", "address_line2", "city", "state", "postal_code")},
        ),
        ("Contact", {"fields": ("phone", "whatsapp_number")}),
        ("Sales tax", {"fields": ("charges_sales_tax", "sales_tax_rate")}),
        ("Timestamps", {"fields": ("created_at", "updated_at")}),
    )


@admin.register(ShopHours)
class ShopHoursAdmin(admin.ModelAdmin):
    """Admin for individual weekday opening hours."""

    list_display = ("shop", "weekday", "open_time", "close_time", "is_closed")
    list_filter = ("shop", "weekday", "is_closed")
    ordering = ("shop", "weekday")
