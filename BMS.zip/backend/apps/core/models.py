"""Shop-level configuration models.

A single installation serves one barbershop, but the shop is modelled as a row
(rather than settings constants) so that address, tax and opening hours can be
edited from the admin without a deploy.
"""

from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models
from django.utils.translation import gettext_lazy as _

US_STATE_CHOICES = [
    ("AL", "Alabama"),
    ("AK", "Alaska"),
    ("AZ", "Arizona"),
    ("AR", "Arkansas"),
    ("CA", "California"),
    ("CO", "Colorado"),
    ("CT", "Connecticut"),
    ("DE", "Delaware"),
    ("DC", "District of Columbia"),
    ("FL", "Florida"),
    ("GA", "Georgia"),
    ("HI", "Hawaii"),
    ("ID", "Idaho"),
    ("IL", "Illinois"),
    ("IN", "Indiana"),
    ("IA", "Iowa"),
    ("KS", "Kansas"),
    ("KY", "Kentucky"),
    ("LA", "Louisiana"),
    ("ME", "Maine"),
    ("MD", "Maryland"),
    ("MA", "Massachusetts"),
    ("MI", "Michigan"),
    ("MN", "Minnesota"),
    ("MS", "Mississippi"),
    ("MO", "Missouri"),
    ("MT", "Montana"),
    ("NE", "Nebraska"),
    ("NV", "Nevada"),
    ("NH", "New Hampshire"),
    ("NJ", "New Jersey"),
    ("NM", "New Mexico"),
    ("NY", "New York"),
    ("NC", "North Carolina"),
    ("ND", "North Dakota"),
    ("OH", "Ohio"),
    ("OK", "Oklahoma"),
    ("OR", "Oregon"),
    ("PA", "Pennsylvania"),
    ("RI", "Rhode Island"),
    ("SC", "South Carolina"),
    ("SD", "South Dakota"),
    ("TN", "Tennessee"),
    ("TX", "Texas"),
    ("UT", "Utah"),
    ("VT", "Vermont"),
    ("VA", "Virginia"),
    ("WA", "Washington"),
    ("WV", "West Virginia"),
    ("WI", "Wisconsin"),
    ("WY", "Wyoming"),
]


class Weekday(models.IntegerChoices):
    """Weekday numbering matching :meth:`datetime.date.weekday` (Mon=0)."""

    MONDAY = 0, _("Monday")
    TUESDAY = 1, _("Tuesday")
    WEDNESDAY = 2, _("Wednesday")
    THURSDAY = 3, _("Thursday")
    FRIDAY = 4, _("Friday")
    SATURDAY = 5, _("Saturday")
    SUNDAY = 6, _("Sunday")


class Shop(models.Model):
    """The barbershop: address, contact numbers and sales-tax configuration."""

    name = models.CharField(_("name"), max_length=120)

    address_line1 = models.CharField(_("address line 1"), max_length=200)
    address_line2 = models.CharField(_("address line 2"), max_length=200, blank=True)
    city = models.CharField(_("city"), max_length=100)
    state = models.CharField(
        _("state"),
        max_length=2,
        choices=US_STATE_CHOICES,
        validators=[
            RegexValidator(
                r"^[A-Z]{2}$",
                message=_("State must be a 2-letter uppercase US state code."),
            )
        ],
    )
    postal_code = models.CharField(
        _("postal code"),
        max_length=10,
        validators=[
            RegexValidator(
                r"^\d{5}(-\d{4})?$",
                message=_("Enter a ZIP code as 12345 or 12345-6789."),
            )
        ],
    )

    timezone = models.CharField(
        _("timezone"),
        max_length=64,
        default="America/New_York",
        help_text=_("IANA timezone name used for all booking times."),
    )

    phone = models.CharField(_("phone"), max_length=20, blank=True)
    whatsapp_number = models.CharField(
        _("WhatsApp number"),
        max_length=20,
        blank=True,
        help_text=_("E.164 number the booking bot replies from, e.g. +15551234567."),
    )

    charges_sales_tax = models.BooleanField(_("charges sales tax"), default=False)
    sales_tax_rate = models.DecimalField(
        _("sales tax rate"),
        max_digits=5,
        decimal_places=4,
        default=Decimal("0"),
        validators=[MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("1"))],
        help_text=_("Fraction of the subtotal, e.g. 0.0875 for 8.75%."),
    )

    created_at = models.DateTimeField(_("created at"), auto_now_add=True)
    updated_at = models.DateTimeField(_("updated at"), auto_now=True)

    class Meta:
        verbose_name = _("shop")
        verbose_name_plural = _("shops")
        ordering = ("name",)

    def __str__(self):
        return self.name

    @property
    def full_address(self):
        """Single-line postal address, skipping an empty second address line."""
        street = ", ".join(part for part in (self.address_line1, self.address_line2) if part)
        return f"{street}, {self.city}, {self.state} {self.postal_code}"


class ShopHours(models.Model):
    """Opening and closing time for one weekday at one shop."""

    shop = models.ForeignKey(
        Shop,
        on_delete=models.CASCADE,
        related_name="hours",
        verbose_name=_("shop"),
    )
    weekday = models.PositiveSmallIntegerField(_("weekday"), choices=Weekday.choices)
    open_time = models.TimeField(_("open time"), null=True, blank=True)
    close_time = models.TimeField(_("close time"), null=True, blank=True)
    is_closed = models.BooleanField(_("closed all day"), default=False)

    class Meta:
        verbose_name = _("shop hours")
        verbose_name_plural = _("shop hours")
        ordering = ("shop", "weekday")
        constraints = [
            models.UniqueConstraint(
                fields=("shop", "weekday"),
                name="unique_shop_hours_per_weekday",
            )
        ]

    def __str__(self):
        if self.is_closed:
            return f"{self.get_weekday_display()}: closed"
        return f"{self.get_weekday_display()}: {self.open_time}-{self.close_time}"
