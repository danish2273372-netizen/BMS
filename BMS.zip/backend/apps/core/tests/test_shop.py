"""Tests for the Shop and ShopHours models."""

from datetime import time
from decimal import Decimal

import pytest
from django.db import IntegrityError, transaction

from apps.core.models import Shop, ShopHours, Weekday

pytestmark = pytest.mark.django_db


def make_shop(**overrides):
    defaults = {
        "name": "Fade Factory",
        "address_line1": "12 Main St",
        "city": "Newark",
        "state": "NJ",
        "postal_code": "07102",
        "phone": "+15551230000",
        "whatsapp_number": "+15551230001",
    }
    defaults.update(overrides)
    return Shop.objects.create(**defaults)


def test_shop_str_is_name():
    shop = make_shop()
    assert str(shop) == "Fade Factory"


def test_shop_tax_and_timezone_defaults():
    shop = make_shop()
    assert shop.timezone == "America/New_York"
    assert shop.charges_sales_tax is False
    assert shop.sales_tax_rate == Decimal("0")


def test_shop_full_address_skips_blank_line2():
    shop = make_shop()
    assert shop.full_address == "12 Main St, Newark, NJ 07102"

    shop.address_line2 = "Suite 4"
    assert shop.full_address == "12 Main St, Suite 4, Newark, NJ 07102"


def test_shop_hours_defaults_and_str():
    shop = make_shop()
    hours = ShopHours.objects.create(
        shop=shop,
        weekday=Weekday.MONDAY,
        open_time=time(9, 0),
        close_time=time(18, 0),
    )
    assert hours.is_closed is False
    assert str(hours) == "Monday: 09:00:00-18:00:00"

    closed = ShopHours.objects.create(shop=shop, weekday=Weekday.SUNDAY, is_closed=True)
    assert str(closed) == "Sunday: closed"


def test_shop_hours_unique_per_weekday():
    shop = make_shop()
    ShopHours.objects.create(
        shop=shop, weekday=Weekday.TUESDAY, open_time=time(9, 0), close_time=time(17, 0)
    )

    with pytest.raises(IntegrityError):
        with transaction.atomic():
            ShopHours.objects.create(
                shop=shop,
                weekday=Weekday.TUESDAY,
                open_time=time(10, 0),
                close_time=time(19, 0),
            )


def test_shop_hours_same_weekday_allowed_for_another_shop():
    shop_a = make_shop()
    shop_b = make_shop(name="Second Chair")

    ShopHours.objects.create(
        shop=shop_a, weekday=Weekday.WEDNESDAY, open_time=time(9, 0), close_time=time(17, 0)
    )
    ShopHours.objects.create(
        shop=shop_b, weekday=Weekday.WEDNESDAY, open_time=time(9, 0), close_time=time(17, 0)
    )

    assert ShopHours.objects.filter(weekday=Weekday.WEDNESDAY).count() == 2
