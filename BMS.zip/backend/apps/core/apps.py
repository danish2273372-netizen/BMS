from django.apps import AppConfig


class CoreConfig(AppConfig):
    """App config for shop-wide configuration (the shop itself and its hours).

    Lives under the ``apps.`` package but keeps the short label ``core`` so
    that references such as ``core.Shop`` resolve.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.core"
    label = "core"
    verbose_name = "Core"
