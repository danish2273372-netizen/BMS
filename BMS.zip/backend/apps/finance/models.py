"""Finance models for the barbershop management system.

Expenses are logged for tracking operational costs.  Rent payments are
tracked per-barber with period boundaries and a unique constraint to
prevent duplicates.
"""

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models
from django.utils.translation import gettext_lazy as _

User = get_user_model()


# ── Choices ─────────────────────────────────────────────────────────────


class ExpenseCategory(models.TextChoices):
    """Expense categories for operational cost tracking."""

    RENT = "rent", _("Rent")
    UTILITIES = "utilities", _("Utilities")
    SUPPLIES = "supplies", _("Supplies")
    MARKETING = "marketing", _("Marketing")
    OTHER = "other", _("Other")


# ── Models ──────────────────────────────────────────────────────────────


class Expense(models.Model):
    """An operational expense incurred by the barbershop."""

    category = models.CharField(
        _("category"),
        max_length=16,
        choices=ExpenseCategory.choices,
        default=ExpenseCategory.OTHER,
    )
    amount = models.DecimalField(
        _("amount"),
        max_digits=8,
        decimal_places=2,
    )
    date = models.DateField(_("date"))
    barber = models.ForeignKey(
        "barbers.Barber",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("barber"),
        related_name="expenses",
        help_text=_(
            "Barber who incurred this expense, if applicable."
        ),
    )
    note = models.TextField(_("note"), blank=True, default="")
    receipt = models.FileField(
        _("receipt"),
        upload_to="finance/receipts/%Y/%m/%d/",
        blank=True,
        null=True,
        help_text=_("Optional receipt image or PDF."),
    )
    created_at = models.DateTimeField(
        _("created at"),
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        _("updated at"),
        auto_now=True,
    )

    class Meta:
        verbose_name = _("expense")
        verbose_name_plural = _("expenses")
        ordering = ("-date", "-created_at")

    def __str__(self):
        return f"{self.category} – {self.amount}"


class RentPayment(models.Model):
    """A rent payment made by a barber for a specific period.

    The composite unique constraint on ``barber`` and ``period_start``
    prevents duplicate entries for the same period.
    """

    barber = models.ForeignKey(
        "barbers.Barber",
        on_delete=models.CASCADE,
        verbose_name=_("barber"),
        related_name="rent_payments",
    )
    amount = models.DecimalField(
        _("amount"),
        max_digits=8,
        decimal_places=2,
    )
    period_start = models.DateField(_("period start"))
    period_end = models.DateField(_("period end"))
    period_label = models.CharField(
        _("period label"),
        max_length=60,
        blank=True,
        default="",
        help_text=_(
            'Human-readable label like "January 2025" for display.'
        ),
    )
    paid = models.BooleanField(_("paid"), default=False)
    paid_date = models.DateField(_("paid date"), null=True, blank=True)
    created_at = models.DateTimeField(
        _("created at"),
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        _("updated at"),
        auto_now=True,
    )

    class Meta:
        verbose_name = _("rent payment")
        verbose_name_plural = _("rent payments")
        ordering = ("-period_start",)
        unique_together = (("barber", "period_start"),)

    def __str__(self):
        status = "Paid" if self.paid else "Unpaid"
        return f"{self.barber.display_name} – {self.period_label} – {status}"

    def clean(self):
        """Validate rent payment constraints before saving."""
        super().clean()
        if self.period_start and self.period_end and self.period_start > self.period_end:
            raise ValidationError(
                _("period_start must be before period_end."),
                code="period_order",
            )
