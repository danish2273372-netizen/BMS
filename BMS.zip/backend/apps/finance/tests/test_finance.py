"""Tests for the finance app."""

import datetime
from decimal import Decimal

import pytest
from django.core.exceptions import ValidationError
from django.core.files.uploadedfile import SimpleUploadedFile
from django.db import IntegrityError

from apps.barbers.models import Barber
from apps.core.models import Shop
from apps.finance.models import Expense, ExpenseCategory, RentPayment
from apps.accounts.models import User

pytestmark = pytest.mark.django_db


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture()
def shop():
    return Shop.objects.create(
        name="Test Shop",
        address_line1="123 Main St",
        city="Springfield",
        state="IL",
        postal_code="62704",
        timezone="UTC",
    )


@pytest.fixture()
def barber(shop):
    user = User.objects.create_user(
        phone="+15551234567",
        full_name="Ada Barber",
        pin="1234",
    )
    return Barber.objects.create(
        user=user,
        shop=shop,
        display_name="Ada",
        chair_number=1,
    )


# ── Expense tests ──────────────────────────────────────────────────────


class TestExpense:
    """Tests for the Expense model."""

    def test_str_representation(self, barber):
        exp = Expense.objects.create(
            amount=Decimal("50.00"),
            date=datetime.date.today(),
            category=ExpenseCategory.SUPPLIES,
            barber=barber,
            note="Paper towels",
        )
        assert "supplies" in str(exp).lower()

    def test_category_choices(self):
        choices = [c[0] for c in ExpenseCategory.choices]
        assert ExpenseCategory.RENT in choices
        assert ExpenseCategory.UTILITIES in choices
        assert ExpenseCategory.SUPPLIES in choices
        assert ExpenseCategory.MARKETING in choices
        assert ExpenseCategory.OTHER in choices

    def test_receipt_optional(self, barber):
        """Receipt field is optional."""
        exp = Expense.objects.create(
            amount=Decimal("100.00"),
            date=datetime.date.today(),
            barber=barber,
        )
        assert not exp.receipt

    def test_receipt_accepted(self, barber):
        """Receipt accepts a file upload."""
        file_content = b"PDF content here"
        receipt_file = SimpleUploadedFile("receipt.pdf", file_content, content_type="application/pdf")
        exp = Expense.objects.create(
            amount=Decimal("100.00"),
            date=datetime.date.today(),
            barber=barber,
            receipt=receipt_file,
        )
        assert exp.receipt.name.startswith("finance/receipts/")

    def test_barber_nullable(self):
        """Expense barber field is nullable."""
        exp = Expense.objects.create(
            amount=Decimal("100.00"),
            date=datetime.date.today(),
            category=ExpenseCategory.OTHER,
        )
        assert exp.barber is None

    def test_default_category(self, barber):
        """Default category is OTHER."""
        exp = Expense.objects.create(
            amount=Decimal("100.00"),
            date=datetime.date.today(),
            barber=barber,
        )
        assert exp.category == ExpenseCategory.OTHER


# ── RentPayment tests ──────────────────────────────────────────────────


class TestRentPayment:
    """Tests for the RentPayment model."""

    def test_str_representation(self, barber):
        rp = RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 1, 1),
            period_end=datetime.date(2025, 1, 31),
            period_label="January 2025",
            paid=False,
        )
        assert "Ada" in str(rp)
        assert "January 2025" in str(rp)

    def test_duplicate_period_rejected(self, barber):
        """Two RentPayments with the same barber and period_start are rejected."""
        RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 1, 1),
            period_end=datetime.date(2025, 1, 31),
            period_label="January 2025",
        )
        with pytest.raises(IntegrityError):
            RentPayment.objects.create(
                barber=barber,
                amount=Decimal("600.00"),
                period_start=datetime.date(2025, 1, 1),
                period_end=datetime.date(2025, 1, 28),
                period_label="January 2025 (shorter)",
            )

    def test_period_end_before_start_rejected(self, barber):
        """period_start must be before period_end."""
        rp = RentPayment(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 2, 1),
            period_end=datetime.date(2025, 1, 1),
            period_label="Backwards period",
        )
        with pytest.raises(ValidationError):
            rp.full_clean()

    def test_paid_status_fields(self, barber):
        """Paid fields are set correctly."""
        rp = RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 3, 1),
            period_end=datetime.date(2025, 3, 31),
            period_label="March 2025",
            paid=True,
            paid_date=datetime.date(2025, 3, 15),
        )
        assert rp.paid is True
        assert rp.paid_date == datetime.date(2025, 3, 15)

    def test_unique_together_on_barber_period_start(self, barber):
        """Unique constraint on (barber, period_start) is enforced."""
        RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 4, 1),
            period_end=datetime.date(2025, 4, 30),
            period_label="April 2025",
        )
        # Different barber, same period_start should be OK
        other_user = User.objects.create_user(
            phone="+15551111111",
            full_name="Bob Barber",
            pin="5678",
        )
        other_barber = Barber.objects.create(
            user=other_user,
            shop=Shop.objects.create(
                name="Other Shop",
                address_line1="456 Other St",
                city="Springfield",
                state="IL",
                postal_code="62705",
                timezone="UTC",
            ),
            display_name="Bob",
            chair_number=2,
        )
        RentPayment.objects.create(
            barber=other_barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 4, 1),
            period_end=datetime.date(2025, 4, 30),
            period_label="April 2025 (different barber)",
        )


class TestRentPaymentOrdering:
    """RentPayment ordering is by period_start descending."""

    def test_ordered_by_period_start_desc(self, barber):
        rp1 = RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 1, 1),
            period_end=datetime.date(2025, 1, 31),
        )
        rp2 = RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 3, 1),
            period_end=datetime.date(2025, 3, 31),
        )
        rp3 = RentPayment.objects.create(
            barber=barber,
            amount=Decimal("500.00"),
            period_start=datetime.date(2025, 2, 1),
            period_end=datetime.date(2025, 2, 28),
        )
        items = list(RentPayment.objects.all())
        assert items[0] == rp2
        assert items[1] == rp3
        assert items[2] == rp1
