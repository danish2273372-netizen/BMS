"""Tests package for the finance app."""
