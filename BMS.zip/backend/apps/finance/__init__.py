"""Finance app for the barbershop management system."""
