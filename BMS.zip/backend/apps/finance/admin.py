"""Admin registration for the finance app."""

from django.contrib import admin

from apps.barbers.models import Barber

from .models import Expense, ExpenseCategory, RentPayment


def _get_barber_for_request(request):
    """Return the Barber instance linked to the request.user, or None."""
    try:
        return request.user.barber_profile
    except AttributeError:
        return None


@admin.register(Expense)
class ExpenseAdmin(admin.ModelAdmin):
    """Admin for :class:`~apps.finance.models.Expense`."""

    list_display = (
        "category",
        "amount",
        "date",
        "barber",
        "note",
    )
    list_filter = ("category", "barber", "date")
    search_fields = ("note", "barber__display_name")
    readonly_fields = (
        "category",
        "amount",
        "date",
        "barber",
        "note",
        "receipt",
        "created_at",
        "updated_at",
    )

    fieldsets = (
        (None, {"fields": ("category", "amount", "date", "barber")}),
        ("Details", {"fields": ("note", "receipt")}),
        (
            "Timestamps",
            {"fields": ("created_at", "updated_at"), "classes": ("collapse",)},
        ),
    )

    def has_add_permission(self, request):
        """Barber-role users cannot create expenses."""
        return not (request.user.is_staff and not request.user.is_superuser)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser or request.user.is_owner:
            return qs
        barber = _get_barber_for_request(request)
        if barber:
            return qs.filter(barber=barber)
        return qs.none()

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        if obj is None:
            # Barbers get no changelist access to expenses at all.
            return False
        barber = _get_barber_for_request(request)
        if barber and obj.barber_id == barber.id:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        barber = _get_barber_for_request(request)
        if barber and obj and obj.barber_id == barber.id:
            return True
        return False


@admin.register(RentPayment)
class RentPaymentAdmin(admin.ModelAdmin):
    """Admin for :class:`~apps.finance.models.RentPayment`."""

    list_display = (
        "barber",
        "amount",
        "period_label",
        "period_start",
        "period_end",
        "paid",
        "paid_date",
    )
    list_filter = ("paid", "barber")
    search_fields = ("barber__display_name", "period_label")
    readonly_fields = (
        "barber",
        "amount",
        "period_start",
        "period_end",
        "period_label",
        "paid",
        "paid_date",
        "created_at",
        "updated_at",
    )

    fieldsets = (
        (None, {"fields": ("barber", "amount", "period_label")}),
        (
            "Period",
            {
                "fields": ("period_start", "period_end"),
            },
        ),
        (
            "Payment status",
            {
                "fields": ("paid", "paid_date"),
            },
        ),
        (
            "Timestamps",
            {
                "fields": ("created_at", "updated_at"),
                "classes": ("collapse",),
            },
        ),
    )

    def has_add_permission(self, request):
        """Barber-role users cannot create rent payments."""
        return not (request.user.is_staff and not request.user.is_superuser)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser or request.user.is_owner:
            return qs
        barber = _get_barber_for_request(request)
        if barber:
            return qs.filter(barber=barber)
        return qs.none()

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        if obj is None:
            return _get_barber_for_request(request) is not None
        barber = _get_barber_for_request(request)
        if barber and obj.barber_id == barber.id:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        barber = _get_barber_for_request(request)
        if barber and obj and obj.barber_id == barber.id:
            return True
        return False
