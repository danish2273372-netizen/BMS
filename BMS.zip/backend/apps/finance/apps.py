"""Django AppConfig for the finance application."""

from django.apps import AppConfig


class FinanceConfig(AppConfig):
    """Finance tracking configuration."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.finance"
    verbose_name = "Finance"
