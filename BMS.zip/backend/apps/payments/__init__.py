"""Payments app for the barbershop management system."""
