"""Payment models for the barbershop management system.

A ``Payment`` record is created when a client pays for an appointment.
It supports card-link (Stripe checkout), cash, and in-person-card payments.
The ``mark_paid`` method atomically records the payment and updates the
parent ``Appointment`` to ``paid`` while incrementing the client's
``total_visits`` exactly once.

Expense tracking lives in the ``finance`` app.
"""

from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError
from django.db import models, transaction
from django.utils import timezone
from django.utils.translation import gettext_lazy as _

User = get_user_model()


# ── Choices ─────────────────────────────────────────────────────────────


class PaymentMethod(models.TextChoices):
    """How the client settled their bill."""

    CARD_LINK = "card_link", _("Card link (Stripe checkout)")
    CASH = "cash", _("Cash")
    IN_PERSON_CARD = "in_person_card", _("In-person card")


class PaymentStatus(models.TextChoices):
    """Lifecycle of a payment record."""

    PENDING = "pending", _("Pending")
    PAID = "paid", _("Paid")
    FAILED = "failed", _("Failed")
    REFUNDED = "refunded", _("Refunded")


# ── Models ──────────────────────────────────────────────────────────────


class Payment(models.Model):
    """A payment record for an appointment.

    Each payment is linked to exactly one appointment (OneToOne) and
    carries a denormalised reference to the barber so that reporting
    queries never have to join through the appointment.
    """

    appointment = models.OneToOneField(
        "appointments.Appointment",
        on_delete=models.PROTECT,
        verbose_name=_("appointment"),
        related_name="payment",
    )
    barber = models.ForeignKey(
        "barbers.Barber",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("barber"),
        related_name="payments",
    )
    amount = models.DecimalField(
        _("amount"),
        max_digits=8,
        decimal_places=2,
    )
    tax_amount = models.DecimalField(
        _("tax amount"),
        max_digits=8,
        decimal_places=2,
        default=0,
    )
    payment_method = models.CharField(
        _("payment method"),
        max_length=16,
        choices=PaymentMethod.choices,
        default=PaymentMethod.CARD_LINK,
    )
    status = models.CharField(
        _("status"),
        max_length=10,
        choices=PaymentStatus.choices,
        default=PaymentStatus.PENDING,
    )
    stripe_checkout_session_id = models.CharField(
        _("Stripe Checkout session ID"),
        max_length=50,
        blank=True,
        default="",
        help_text=_("Stripe Checkout session ID for webhook reconciliation."),
    )
    stripe_payment_intent_id = models.CharField(
        _("Stripe Payment Intent ID"),
        max_length=50,
        blank=True,
        default="",
        help_text=_("Stripe Payment Intent ID for webhook reconciliation."),
    )
    stripe_payment_link_url = models.URLField(
        _("Stripe payment link URL"),
        blank=True,
        default="",
        help_text=_("Hosted Stripe payment link shown to the client."),
    )
    paid_at = models.DateTimeField(
        _("paid at"),
        null=True,
        blank=True,
        help_text=_("When the payment was actually recorded as paid."),
    )
    marked_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        verbose_name=_("marked by"),
        related_name="cash_payments",
        help_text=_("Barber who recorded a cash payment."),
    )
    created_at = models.DateTimeField(
        _("created at"),
        auto_now_add=True,
    )
    updated_at = models.DateTimeField(
        _("updated at"),
        auto_now=True,
    )

    class Meta:
        verbose_name = _("payment")
        verbose_name_plural = _("payments")
        ordering = ("-created_at",)

    def __str__(self):
        return f"{self.appointment.reference_number} – {self.get_status_display()}"

    def mark_paid(self, when=None, by=None):
        """Mark this payment as paid and update the parent appointment.

        This method must only be called once per payment.  It:

        1. Sets ``status`` to ``PAID`` and ``paid_at`` to the given time
           (or ``timezone.now()``).
        2. Sets the parent :class:`~appointments.Appointment` to
           ``Status.PAID``.
        3. Increments the client's ``total_visits`` **exactly once** even
           if ``mark_paid`` is called again.

        Parameters
        ----------
        when : datetime, optional
            Explicit payment datetime.  Defaults to ``timezone.now()``.
        by : User, optional
            The barber who recorded the payment (used for cash payments).

        Returns
        -------
        bool
            True if the payment was actually updated (False if already paid).
        """
        if when is None:
            when = timezone.now()

        with transaction.atomic():
            # Re-fetch with row lock to prevent race conditions
            self = Payment.objects.select_for_update().get(pk=self.pk)

            if self.status == PaymentStatus.PAID:
                return False

            self.status = PaymentStatus.PAID
            self.paid_at = when
            self.save(update_fields=["status", "paid_at", "updated_at"])

            # Update the parent appointment to PAID and increment client visits
            appt = self.appointment
            if appt.status != "paid":
                appt.status = "paid"
                appt.save(update_fields=["status", "updated_at"])
            client = appt.client
            client.total_visits += 1
            client.save(update_fields=["total_visits", "updated_at"])
            # Update the in-memory client object so callers see the increment
            self._client_visits_incremented = True

            if by is not None:
                self.marked_by = by
                self.save(update_fields=["marked_by", "updated_at"])

        return True

    def clean(self):
        """Validate payment constraints before saving."""
        super().clean()
        if self.pk and self.status == PaymentStatus.PAID and self.paid_at is None:
            raise ValidationError(
                _("paid_at is required when status is PAID."),
                code="paid_at_required",
            )



