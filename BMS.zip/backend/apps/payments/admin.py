"""Admin registration for the payments app."""

from django.contrib import admin

from apps.barbers.models import Barber

from .models import Payment


def _get_barber_for_request(request):
    """Return the Barber instance linked to the request.user, or None."""
    try:
        return request.user.barber_profile
    except AttributeError:
        return None


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    """Admin for :class:`~apps.payments.models.Payment`."""

    list_display = (
        "appointment",
        "barber",
        "amount",
        "tax_amount",
        "payment_method",
        "status",
        "paid_at",
    )
    list_filter = ("status", "payment_method", "barber")
    search_fields = (
        "appointment__reference_number",
        "barber__display_name",
    )
    readonly_fields = (
        "appointment",
        "barber",
        "amount",
        "tax_amount",
        "payment_method",
        "stripe_checkout_session_id",
        "stripe_payment_intent_id",
        "stripe_payment_link_url",
        "paid_at",
        "marked_by",
        "created_at",
        "updated_at",
    )

    fieldsets = (
        (None, {"fields": ("appointment", "barber", "amount", "tax_amount")}),
        (
            "Payment details",
            {
                "fields": (
                    "payment_method",
                    "status",
                    "paid_at",
                    "marked_by",
                )
            },
        ),
        (
            "Stripe",
            {
                "fields": (
                    "stripe_checkout_session_id",
                    "stripe_payment_intent_id",
                    "stripe_payment_link_url",
                )
            },
        ),
        (
            "Timestamps",
            {
                "fields": ("created_at", "updated_at"),
                "classes": ("collapse",),
            },
        ),
    )

    def has_add_permission(self, request):
        """Barber-role users cannot create payments."""
        return not (request.user.is_staff and not request.user.is_superuser)

    def get_queryset(self, request):
        qs = super().get_queryset(request)
        if request.user.is_superuser or request.user.is_owner:
            return qs
        barber = _get_barber_for_request(request)
        if barber:
            return qs.filter(barber=barber)
        return qs.none()

    def has_change_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        if obj is None:
            return _get_barber_for_request(request) is not None
        barber = _get_barber_for_request(request)
        if barber and obj.barber_id == barber.id:
            return True
        return False

    def has_delete_permission(self, request, obj=None):
        if request.user.is_superuser or request.user.is_owner:
            return True
        barber = _get_barber_for_request(request)
        if barber and obj and obj.barber_id == barber.id:
            return True
        return False
