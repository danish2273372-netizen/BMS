"""Tests for the payments app."""

from datetime import datetime
from decimal import Decimal

import pytest
from django.core.exceptions import ValidationError
from django.utils import timezone

from apps.appointments.models import Appointment, AppointmentService, Status
from apps.barbers.models import Barber
from apps.clients.models import Client
from apps.payments.models import Payment, PaymentMethod, PaymentStatus
from apps.core.models import Shop
from apps.accounts.models import User

pytestmark = pytest.mark.django_db


# ── Fixtures ────────────────────────────────────────────────────────────


@pytest.fixture()
def shop():
    return Shop.objects.create(
        name="Test Shop",
        address_line1="123 Main St",
        city="Springfield",
        state="IL",
        postal_code="62704",
        timezone="UTC",
    )


@pytest.fixture()
def barber(shop):
    user = User.objects.create_user(
        phone="+15551234567",
        full_name="Ada Barber",
        pin="1234",
    )
    return Barber.objects.create(
        user=user,
        shop=shop,
        display_name="Ada",
        chair_number=1,
    )


@pytest.fixture()
def client():
    return Client.objects.create(
        name="John Customer",
        phone="+15559876543",
    )


@pytest.fixture()
def appointment(client, barber):
    apt = Appointment.objects.create(
        client=client,
        barber=barber,
        requested_time=datetime(2025, 6, 15, 14, 0, 0),
        status=Status.BOOKED,
        reference_number="TEST01",
    )
    return apt


@pytest.fixture()
def payment(appointment, barber):
    return Payment.objects.create(
        appointment=appointment,
        barber=barber,
        amount=Decimal("25.00"),
        payment_method=PaymentMethod.CARD_LINK,
    )


# ── Tests ───────────────────────────────────────────────────────────────


class TestMarkPaid:
    """mark_paid flips the appointment to paid."""

    def test_mark_paid_sets_status_and_paid_at(self, payment):
        """mark_paid sets status=PAID and paid_at to now."""
        now = timezone.now()
        result = payment.mark_paid(when=now)
        payment.refresh_from_db()
        assert result is True
        assert payment.status == PaymentStatus.PAID
        assert payment.paid_at is not None
        assert payment.appointment.status == Status.PAID

    def test_mark_paid_updates_barber_field(self, payment, barber):
        """mark_paid with by=barber sets marked_by."""
        admin_user = User.objects.create_user(
            phone="+15551111111",
            full_name="Admin",
            pin="5678",
        )
        payment.mark_paid(by=admin_user)
        payment.refresh_from_db()
        assert payment.marked_by == admin_user

    def test_mark_paid_flips_appointment_to_paid(self, payment):
        """The parent appointment's status becomes PAID after mark_paid."""
        assert payment.appointment.status == Status.BOOKED
        payment.mark_paid()
        payment.appointment.refresh_from_db()
        assert payment.appointment.status == Status.PAID


class TestMarkPaidDoubleCall:
    """Calling mark_paid twice increments total_visits only once."""

    def test_double_call_increments_total_visits_once(self, client, barber, appointment, payment):
        """Two calls to mark_paid must increment total_visits only once."""
        client.refresh_from_db()
        initial_visits = client.total_visits
        payment.mark_paid()
        payment.refresh_from_db()
        client.refresh_from_db()
        first_count = client.total_visits

        payment.mark_paid()  # Should be a no-op
        payment.refresh_from_db()
        client.refresh_from_db()
        second_count = client.total_visits

        assert first_count == initial_visits + 1
        assert second_count == first_count  # Not incremented again
        assert payment.status == PaymentStatus.PAID

    def test_double_call_returns_false_on_second(self, payment):
        """Second call returns False."""
        assert payment.mark_paid() is True
        assert payment.mark_paid() is False

    def test_double_call_appointment_stays_paid(self, payment):
        """Appointment remains PAID after double call."""
        payment.mark_paid()
        appointment_id = payment.appointment_id
        payment.appointment.refresh_from_db()
        initial_status = payment.appointment.status
        payment.mark_paid()
        payment.appointment.refresh_from_db()
        assert payment.appointment.status == initial_status


class TestPaymentModel:
    """Basic model field validations."""

    def test_str_representation(self, payment):
        assert "TEST01" in str(payment)
        assert "Pending" in str(payment)

    def test_payment_method_choices(self, payment):
        valid_methods = [m[0] for m in PaymentMethod.choices]
        assert PaymentMethod.CARD_LINK in valid_methods
        assert PaymentMethod.CASH in valid_methods
        assert PaymentMethod.IN_PERSON_CARD in valid_methods

    def test_payment_status_choices(self):
        valid_statuses = [s[0] for s in PaymentStatus.choices]
        assert PaymentStatus.PENDING in valid_statuses
        assert PaymentStatus.PAID in valid_statuses
        assert PaymentStatus.FAILED in valid_statuses
        assert PaymentStatus.REFUNDED in valid_statuses


class TestPaymentClean:
    """Validation clean() methods."""

    def test_paid_status_requires_paid_at(self, payment):
        """PAID status requires paid_at to be set."""
        # Mark as paid manually without paid_at — should fail clean
        payment.status = PaymentStatus.PAID
        payment.paid_at = None
        with pytest.raises(ValidationError):
            payment.full_clean()


class TestDuplicateClientVisitsGuard:
    """Ensure total_visits increments exactly once even with multiple mark_paid calls."""

    def test_multiple_payments_different_appointments(self, shop, barber):
        """Different payments for different appointments each increment visits."""
        client = Client.objects.create(
            name="Jane Customer",
            phone="+15559999999",
        )
        apt1 = Appointment.objects.create(
            client=client,
            barber=barber,
            requested_time=datetime(2025, 6, 15, 10, 0, 0),
            status=Status.BOOKED,
            reference_number="TEST02",
        )
        pay1 = Payment.objects.create(
            appointment=apt1,
            barber=barber,
            amount=Decimal("30.00"),
        )

        apt2 = Appointment.objects.create(
            client=client,
            barber=barber,
            requested_time=datetime(2025, 6, 15, 11, 0, 0),
            status=Status.BOOKED,
            reference_number="TEST03",
        )
        pay2 = Payment.objects.create(
            appointment=apt2,
            barber=barber,
            amount=Decimal("35.00"),
        )

        client.refresh_from_db()
        assert client.total_visits == 0
        pay1.mark_paid()
        client.refresh_from_db()
        assert client.total_visits == 1
        pay2.mark_paid()
        client.refresh_from_db()
        assert client.total_visits == 2
