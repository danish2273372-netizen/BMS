"""Django AppConfig for the payments application."""

from django.apps import AppConfig


class PaymentsConfig(AppConfig):
    """Payment tracking configuration."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.payments"
    verbose_name = "Payments"
