"""Service catalogue models.

A ``Service`` represents one barbershop offering (cut, fade, beard trim, etc.)
with pricing and duration so the WhatsApp booking bot and the barber app can
display and charge for it.
"""

from django.db import models
from django.utils.translation import gettext_lazy as _


class Service(models.Model):
    """A service the barbershop provides."""

    name = models.CharField(_("name"), max_length=120)
    description = models.TextField(_("description"), blank=True)
    price = models.DecimalField(_("price"), max_digits=8, decimal_places=2)
    duration_minutes = models.PositiveIntegerField(_("duration (minutes)"))
    active = models.BooleanField(_("active"), default=True)
    ordering = models.PositiveIntegerField(_("ordering"), default=0)

    class Meta:
        verbose_name = _("service")
        verbose_name_plural = _("services")
        ordering = ("ordering", "name")

    def __str__(self):
        return self.name
