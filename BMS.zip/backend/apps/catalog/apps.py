from django.apps import AppConfig


class CatalogConfig(AppConfig):
    """App config for the service catalogue (what the shop sells).

    Lives under the ``apps.`` package but keeps the short label ``catalog``
    so that references such as ``catalog.Service`` resolve.
    """

    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.catalog"
    label = "catalog"
    verbose_name = "Catalog"
