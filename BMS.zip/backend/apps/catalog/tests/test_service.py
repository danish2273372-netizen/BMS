"""Tests for the Service model."""

import pytest
from decimal import Decimal

from apps.catalog.models import Service

pytestmark = pytest.mark.django_db


def make_service(**overrides):
    defaults = {
        "name": "Classic Cut",
        "description": "A standard haircut.",
        "price": Decimal("25.00"),
        "duration_minutes": 30,
    }
    defaults.update(overrides)
    return Service.objects.create(**defaults)


def test_service_str():
    service = make_service()
    assert str(service) == "Classic Cut"


def test_service_str_custom_name():
    service = make_service(name="Beard Trim")
    assert str(service) == "Beard Trim"


def test_service_active_default():
    service = make_service()
    assert service.active is True


def test_service_active_can_be_false():
    service = make_service(active=False)
    assert service.active is False


def test_service_price_default():
    service = make_service(price=Decimal("30.00"))
    assert service.price == Decimal("30.00")


def test_service_duration_minutes_positive():
    service = make_service(duration_minutes=45)
    assert service.duration_minutes == 45


def test_service_default_ordering():
    make_service(name="First")
    make_service(name="Second")
    assert list(Service.objects.values_list("ordering", flat=True)) == [0, 0]


def test_service_ordered_by_ordering():
    s2 = make_service(name="B", ordering=2)
    s1 = make_service(name="A", ordering=1)
    assert list(Service.objects.order_by("ordering").values_list("name", flat="name")) == [
        "A",
        "B",
    ]
