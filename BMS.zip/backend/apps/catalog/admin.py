"""Admin registration for the service catalogue."""

from django.contrib import admin

from .models import Service


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    """Admin for barbershop services."""

    list_display = ("name", "price", "duration_minutes", "active", "ordering")
    list_filter = ("active",)
    search_fields = ("name", "description")
    ordering = ("ordering",)
