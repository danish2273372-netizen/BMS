--
-- Seed data for barbershop database
-- Populates: clients_client, appointments_appointment, appointments_appointmentservice,
--            payments_payment, finance_expense, finance_rentpayment
--
-- Assumes existing rows: core_shop(id=1), barbers_barber(id=1, user_id=2),
--                         catalog_service(id=1, "Hair Cut", price 20.00, 30 min),
--                         accounts_user(id=1 owner, id=2 barber), discounts_discount(id=1)
--
-- Safe to re-run: wrapped in a transaction, truncates target tables first.

BEGIN;

TRUNCATE TABLE
    public.payments_payment,
    public.appointments_appointmentservice,
    public.appointments_appointment,
    public.finance_rentpayment,
    public.finance_expense,
    public.clients_client
    RESTART IDENTITY CASCADE;

--
-- Clients
--
INSERT INTO public.clients_client (id, name, phone, email, first_visit_date, total_visits, notes, created_at, updated_at, user_id) VALUES
(1, 'Ahmed Raza',      '+15550001001', 'ahmed.raza@example.com',      '2026-08-01', 4, '',                       '2026-08-01 10:00:00+05', '2026-09-20 10:00:00+05', NULL),
(2, 'Bilal Hussain',   '+15550001002', 'bilal.hussain@example.com',   '2026-08-03', 2, '',                       '2026-08-03 11:15:00+05', '2026-09-15 11:15:00+05', NULL),
(3, 'Sana Tariq',      '+15550001003', 'sana.tariq@example.com',      '2026-08-05', 5, 'Prefers evening slots', '2026-08-05 09:30:00+05', '2026-09-22 09:30:00+05', NULL),
(4, 'Usman Malik',     '+15550001004', 'usman.malik@example.com',     '2026-08-10', 1, '',                       '2026-08-10 14:00:00+05', '2026-08-10 14:00:00+05', NULL),
(5, 'Fatima Sheikh',   '+15550001005', 'fatima.sheikh@example.com',   '2026-08-12', 3, '',                       '2026-08-12 16:45:00+05', '2026-09-18 16:45:00+05', NULL),
(6, 'Hamza Iqbal',     '+15550001006', 'hamza.iqbal@example.com',     '2026-08-15', 6, 'Regular, every 2 weeks', '2026-08-15 10:30:00+05', '2026-09-25 10:30:00+05', NULL),
(7, 'Ayesha Noor',     '+15550001007', 'ayesha.noor@example.com',     '2026-08-18', 1, '',                       '2026-08-18 12:00:00+05', '2026-08-18 12:00:00+05', NULL),
(8, 'Zeeshan Ahmed',   '+15550001008', 'zeeshan.ahmed@example.com',   '2026-08-20', 2, '',                       '2026-08-20 13:20:00+05', '2026-09-10 13:20:00+05', NULL),
(9, 'Mehak Younas',    '+15550001009', 'mehak.younas@example.com',    '2026-08-22', 3, '',                       '2026-08-22 15:00:00+05', '2026-09-12 15:00:00+05', NULL),
(10,'Kamran Yousaf',   '+15550001010', 'kamran.yousaf@example.com',   '2026-08-25', 1, '',                       '2026-08-25 17:30:00+05', '2026-08-25 17:30:00+05', NULL),
(11,'Imran Sheikh',    '+15550001011', 'imran.sheikh@example.com',    '2026-08-15', 1, '',                       '2026-08-15 09:45:00+05', '2026-08-15 09:45:00+05', NULL),
(12,'Nida Aslam',      '+15550001012', 'nida.aslam@example.com',      '2026-08-20', 1, '',                       '2026-08-20 10:15:00+05', '2026-08-20 10:15:00+05', NULL),
(13,'Waqas Ali',       '+15550001013', 'waqas.ali@example.com',       '2026-09-24', 1, '',                       '2026-09-24 08:30:00+05', '2026-09-24 08:30:00+05', NULL);

--
-- Appointments
-- status values used: pending, confirmed, completed, cancelled, no_show
-- created_via values used: walk_in, online, phone, admin
--
INSERT INTO public.appointments_appointment (id, requested_time, status, created_via, final_price, reference_number, notes, created_at, updated_at, barber_id, client_id, discount_applied_id) VALUES
(1,  '2026-09-01 10:00:00+05', 'completed', 'walk_in', 20.00, 'AB1001', '',                    '2026-08-31 09:00:00+05', '2026-09-01 10:35:00+05', 1, 1, NULL),
(2,  '2026-09-03 11:00:00+05', 'completed', 'online',  20.00, 'AB1002', '',                    '2026-09-02 12:00:00+05', '2026-09-03 11:32:00+05', 1, 2, NULL),
(3,  '2026-09-05 14:00:00+05', 'completed', 'phone',   19.00, 'AB1003', 'Used New Year promo', '2026-09-04 09:00:00+05', '2026-09-05 14:31:00+05', 1, 3, 1),
(4,  '2026-09-07 09:30:00+05', 'no_show',   'online',  NULL,  'AB1004', 'Client did not show', '2026-09-06 08:00:00+05', '2026-09-07 10:00:00+05', 1, 4, NULL),
(5,  '2026-09-09 16:00:00+05', 'completed', 'walk_in', 20.00, 'AB1005', '',                    '2026-09-09 15:45:00+05', '2026-09-09 16:33:00+05', 1, 5, NULL),
(6,  '2026-09-11 10:30:00+05', 'completed', 'admin',   20.00, 'AB1006', '',                    '2026-09-10 10:00:00+05', '2026-09-11 11:02:00+05', 1, 6, NULL),
(7,  '2026-09-13 13:00:00+05', 'cancelled', 'online',  NULL,  'AB1007', 'Client cancelled',    '2026-09-12 09:00:00+05', '2026-09-12 18:00:00+05', 1, 7, NULL),
(8,  '2026-09-15 15:30:00+05', 'completed', 'walk_in', 20.00, 'AB1008', '',                    '2026-09-15 15:20:00+05', '2026-09-15 16:03:00+05', 1, 8, NULL),
(9,  '2026-09-18 09:00:00+05', 'completed', 'phone',   20.00, 'AB1009', '',                    '2026-09-17 12:00:00+05', '2026-09-18 09:31:00+05', 1, 9, NULL),
(10, '2026-09-20 11:30:00+05', 'completed', 'online',  20.00, 'AB1010', '',                    '2026-09-19 10:00:00+05', '2026-09-20 12:02:00+05', 1, 6, NULL),
(11, '2026-09-22 14:30:00+05', 'completed', 'walk_in', 20.00, 'AB1011', '',                    '2026-09-22 14:20:00+05', '2026-09-22 15:01:00+05', 1, 1, NULL),
(12, '2026-09-24 16:30:00+05', 'confirmed', 'online',  NULL,  'AB1012', '',                    '2026-09-23 10:00:00+05', '2026-09-23 10:00:00+05', 1, 3, NULL),
(13, '2026-09-26 10:00:00+05', 'pending',   'online',  NULL,  'AB1013', '',                    '2026-09-25 20:00:00+05', '2026-09-25 20:00:00+05', 1, 9, NULL),
(14, '2026-09-27 12:00:00+05', 'pending',   'phone',   NULL,  'AB1014', '',                    '2026-09-25 21:00:00+05', '2026-09-25 21:00:00+05', 1, 10, NULL),
(15, '2026-09-28 15:00:00+05', 'confirmed', 'walk_in', NULL,  'AB1015', '',                    '2026-09-25 22:00:00+05', '2026-09-25 22:00:00+05', 1, 5, NULL),
(16, '2026-08-15 10:00:00+05', 'completed', 'walk_in', 20.00, 'AB1016', '',                    '2026-08-15 09:45:00+05', '2026-08-15 10:32:00+05', 1, 11, NULL),
(17, '2026-08-20 11:00:00+05', 'completed', 'online',  20.00, 'AB1017', '',                    '2026-08-20 10:15:00+05', '2026-08-20 11:31:00+05', 1, 12, NULL),
(18, '2026-09-24 09:00:00+05', 'completed', 'phone',   20.00, 'AB1018', '',                    '2026-09-24 08:30:00+05', '2026-09-24 09:33:00+05', 1, 13, NULL),
(19, '2026-09-25 13:00:00+05', 'completed', 'walk_in', 20.00, 'AB1019', '',                    '2026-09-25 12:45:00+05', '2026-09-25 13:32:00+05', 1, 2,  NULL),
(20, '2026-09-26 08:00:00+05', 'completed', 'online',  20.00, 'AB1020', '',                    '2026-09-26 07:30:00+05', '2026-09-26 08:31:00+05', 1, 4,  NULL);

--
-- Appointment services (one Hair Cut per appointment, matches catalog price at time of booking)
--
INSERT INTO public.appointments_appointmentservice (id, price_at_booking, duration_minutes, appointment_id, service_id) VALUES
(1,  20.00, 30, 1,  1),
(2,  20.00, 30, 2,  1),
(3,  20.00, 30, 3,  1),
(4,  20.00, 30, 4,  1),
(5,  20.00, 30, 5,  1),
(6,  20.00, 30, 6,  1),
(7,  20.00, 30, 7,  1),
(8,  20.00, 30, 8,  1),
(9,  20.00, 30, 9,  1),
(10, 20.00, 30, 10, 1),
(11, 20.00, 30, 11, 1),
(12, 20.00, 30, 12, 1),
(13, 20.00, 30, 13, 1),
(14, 20.00, 30, 14, 1),
(15, 20.00, 30, 15, 1),
(16, 20.00, 30, 16, 1),
(17, 20.00, 30, 17, 1),
(18, 20.00, 30, 18, 1),
(19, 20.00, 30, 19, 1),
(20, 20.00, 30, 20, 1);

--
-- Payments (one per appointment that reached payment stage; matches payments_payment_appointment_id_key unique)
-- payment_method values match apps.payments.models.PaymentMethod exactly:
--   'card_link' (Stripe checkout link), 'cash', 'in_person_card'
-- status values match apps.payments.models.PaymentStatus: pending, paid, failed, refunded
--
INSERT INTO public.payments_payment (id, amount, tax_amount, payment_method, status, stripe_checkout_session_id, stripe_payment_intent_id, stripe_payment_link_url, paid_at, created_at, updated_at, appointment_id, barber_id, marked_by_id) VALUES
(1,  20.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-01 10:35:00+05', '2026-09-01 10:35:00+05', '2026-09-01 10:35:00+05', 1,  1, 2),
(2,  20.00, 0.00, 'card_link',      'paid', '', '', '', '2026-09-03 11:32:00+05', '2026-09-03 11:32:00+05', '2026-09-03 11:32:00+05', 2,  1, 2),
(3,  19.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-05 14:31:00+05', '2026-09-05 14:31:00+05', '2026-09-05 14:31:00+05', 3,  1, 2),
(4,  20.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-09 16:33:00+05', '2026-09-09 16:33:00+05', '2026-09-09 16:33:00+05', 5,  1, 2),
(5,  20.00, 0.00, 'in_person_card', 'paid', '', '', '', '2026-09-11 11:02:00+05', '2026-09-11 11:02:00+05', '2026-09-11 11:02:00+05', 6,  1, 2),
(6,  20.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-15 16:03:00+05', '2026-09-15 16:03:00+05', '2026-09-15 16:03:00+05', 8,  1, 2),
(7,  20.00, 0.00, 'card_link',      'paid', '', '', '', '2026-09-18 09:31:00+05', '2026-09-18 09:31:00+05', '2026-09-18 09:31:00+05', 9,  1, 2),
(8,  20.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-20 12:02:00+05', '2026-09-20 12:02:00+05', '2026-09-20 12:02:00+05', 10, 1, 2),
(9,  20.00, 0.00, 'card_link',      'paid', '', '', '', '2026-09-22 15:01:00+05', '2026-09-22 15:01:00+05', '2026-09-22 15:01:00+05', 11, 1, 2),
(10, 20.00, 0.00, 'cash',           'paid', '', '', '', '2026-08-15 10:32:00+05', '2026-08-15 10:32:00+05', '2026-08-15 10:32:00+05', 16, 1, 2),
(11, 20.00, 0.00, 'card_link',      'paid', '', '', '', '2026-08-20 11:31:00+05', '2026-08-20 11:31:00+05', '2026-08-20 11:31:00+05', 17, 1, 2),
(12, 20.00, 0.00, 'in_person_card', 'paid', '', '', '', '2026-09-24 09:33:00+05', '2026-09-24 09:33:00+05', '2026-09-24 09:33:00+05', 18, 1, 2),
(13, 20.00, 0.00, 'cash',           'paid', '', '', '', '2026-09-25 13:32:00+05', '2026-09-25 13:32:00+05', '2026-09-25 13:32:00+05', 19, 1, 2),
(14, 20.00, 0.00, 'card_link',      'paid', '', '', '', '2026-09-26 08:31:00+05', '2026-09-26 08:31:00+05', '2026-09-26 08:31:00+05', 20, 1, 2);

--
-- Finance: expenses for the shop / barber
-- category values used: supplies, utilities, rent, marketing, other
--
INSERT INTO public.finance_expense (id, category, amount, date, note, receipt, created_at, updated_at, barber_id) VALUES
(1, 'supplies',   45.50,  '2026-09-02', 'Clippers and razors', NULL, '2026-09-02 09:00:00+05', '2026-09-02 09:00:00+05', NULL),
(2, 'utilities',  120.00, '2026-09-05', 'Electricity bill',    NULL, '2026-09-05 09:00:00+05', '2026-09-05 09:00:00+05', NULL),
(3, 'marketing',  30.00,  '2026-09-10', 'Local flyers',        NULL, '2026-09-10 09:00:00+05', '2026-09-10 09:00:00+05', NULL),
(4, 'supplies',   18.75,  '2026-09-18', 'Hair gel and towels', NULL, '2026-09-18 09:00:00+05', '2026-09-18 09:00:00+05', 1),
(5, 'other',      25.00,  '2026-09-22', 'Shop cleaning',       NULL, '2026-09-22 09:00:00+05', '2026-09-22 09:00:00+05', NULL),
(6, 'supplies',   32.00,  '2026-09-24', 'Shampoo restock',     NULL, '2026-09-24 09:00:00+05', '2026-09-24 09:00:00+05', 1);

--
-- Finance: barber rent payments (unique per barber_id + period_start)
--
INSERT INTO public.finance_rentpayment (id, amount, period_start, period_end, period_label, paid, paid_date, created_at, updated_at, barber_id) VALUES
(1, 10.00, '2026-08-01', '2026-08-31', 'August 2026',    true,  '2026-08-05', '2026-08-01 09:00:00+05', '2026-08-05 09:00:00+05', 1),
(2, 10.00, '2026-09-01', '2026-09-30', 'September 2026', false, NULL,         '2026-09-01 09:00:00+05', '2026-09-01 09:00:00+05', 1),
(3, 10.00, '2026-07-01', '2026-07-31', 'July 2026',      true,  '2026-07-03', '2026-07-01 09:00:00+05', '2026-07-03 09:00:00+05', 1);

--
-- Reset sequences so the app can keep inserting new rows without collisions
--
SELECT pg_catalog.setval('public.clients_client_id_seq', (SELECT MAX(id) FROM public.clients_client), true);
SELECT pg_catalog.setval('public.appointments_appointment_id_seq', (SELECT MAX(id) FROM public.appointments_appointment), true);
SELECT pg_catalog.setval('public.appointments_appointmentservice_id_seq', (SELECT MAX(id) FROM public.appointments_appointmentservice), true);
SELECT pg_catalog.setval('public.payments_payment_id_seq', (SELECT MAX(id) FROM public.payments_payment), true);
SELECT pg_catalog.setval('public.finance_expense_id_seq', (SELECT MAX(id) FROM public.finance_expense), true);
SELECT pg_catalog.setval('public.finance_rentpayment_id_seq', (SELECT MAX(id) FROM public.finance_rentpayment), true);

COMMIT;
